package com.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.junit.Test;

public class ProducerTest {

    @Test
    public void produceTest() {

        Properties props = new Properties();
        props.put("bootstrap.servers", "192.168.3.6:9092,192.168.3.6:9093,192.168.3.6:9094");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        // 需要多少个副本应答才算发送结束
        props.put("acks", "all");
        // 自定义分区规则
//        props.put("partitioner.class", DefaultPartitioner.class.getName());
        // 如果发送失败，重试几次
        props.put("retries", 0);
        // 针对每个分区，多少数据才发送一次(bytes),每次send这是存入producer端的缓存，等达到指定数据大小和时间才会真的执行发送，可以有效提高性能，减少请求次数
        props.put("batch.size", 16384);
        // 多久发送一次。如果数据已经达到BATCH_SIZE_CONFIG则立刻发送，否则会登上LINGER_MS_CONFIG毫秒才会执行发送，可以有效提高性能，减少请求次数
        props.put("linger.ms", 1);
        // 生产者缓冲区最大内存占用，此参数在tcp拥堵是需要注意设置，超过之后将不在发送，而是阻塞max.block.ms(默认值是60秒)，如果超过这个时间还是无法发送，则抛出异常
        props.put("buffer.memory", "4194304");

        // 客户端等待请求响应的最大时间
        props.put("request.timeout.ms", 3000);
//        props.put(ProducerConfig.ACKS_CONFIG, "1");
        props.put(ProducerConfig.RETRIES_CONFIG, "2"); //重试次数

        //连接失败时，当我们重新连接时的等待时间
        props.put("reconnect.backoff.ms", 1000);

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);

        for (int i = 51; i < 100; i++) {
            try {
                ProducerRecord<String, String> record =
                        new ProducerRecord<String, String>("my-replicated-topic", "test_key_" + i, "test_value_" + i);
                producer.send(record, new Callback() {

                    @Override
                    public void onCompletion(RecordMetadata metadata, Exception exception) {

                        //	long offset = metadata.offset();
                        //	int partition = metadata.partition();
                        //	long timestamp = metadata.timestamp();
                        //	String topic = metadata.topic();
                        //	String metadataString = metadata.toString();
                        if (exception == null) {
                            System.out.println("发送成功无异常");
                        } else {
                            System.out.println("发送失败有异常：");
                            exception.printStackTrace();
                        }
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        producer.close();

    }

}