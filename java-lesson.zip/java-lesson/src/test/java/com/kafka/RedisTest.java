package com.kafka;

import java.util.Set;

import org.junit.Test;

import redis.clients.jedis.Jedis;


public class RedisTest {

    @Test
    public void test1() throws Exception {

        Jedis jedis = new Jedis("192.168.3.6", 6379);
        String queueKey = "aa";

        while(true) {
            Set<String> values = jedis.zrange(queueKey, 0, System.currentTimeMillis());
            Thread.sleep(1000);


        }
    }

    @Test
    public void print() {
        String s  ="*3\r\n$3\r\nset\r\n$6\r\nauthor\r\n$8\r\ncodehole\r\n";
        System.out.println(s);

    }

}
