package com.kafka;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.junit.Test;


public class ConsumerTest {

    @Test
    public void test1() throws Exception {
        Properties prop = new Properties();
        prop.put("bootstrap.servers", "192.168.3.6:9092,192.168.3.6:9093,192.168.3.6:9094");
        prop.put("group.id", "group-1");
        prop.put("enable.auto.commit", "true");
        prop.put("auto.commit.interval.ms", "1000");
        prop.put("auto.offset.reset", "earliest");
        prop.put("session.timeout.ms", "30000");
        prop.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        prop.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(prop);
        consumer.subscribe(Arrays.asList("my-replicated-topic"));

        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(100);
            if(records == null || records.count() == 0) {
                Thread.sleep(100);
                continue;
            }
            for(ConsumerRecord<String, String> record : records) {

                System.out.println("the key =" + record.key());
                System.out.println("the topic =" + record.topic());
                System.out.println("the value =" + record.value());
                System.out.println("the offset =" + record.offset());
                System.out.println("the partition =" + record.partition());
                System.out.println("the timestamp =" + record.timestamp());
                System.out.println("the record to string =" + record.toString());
                System.out.println("=========================================");

            }
            try {
                Thread.sleep(100);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
