package com.spring;


import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.lesson2.aop.PersonMan;

@SuppressWarnings("resource")
public class AopTest{
	
	@Test
	public void test() {
		ApplicationContext context = new ClassPathXmlApplicationContext("aop2.xml");
		PersonMan person = context.getBean(PersonMan.class);
		String name = person.sayHello("nnzhang");
		System.out.println("my name is " + name);
		
	}
}