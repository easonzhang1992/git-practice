package com.spring;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.lesson1.Dog;
import com.spring.lesson1.Man;
import com.spring.lesson1.MyConfiguration;
import com.spring.lesson1.Person;
import com.spring.lesson1.User;
import com.spring.lesson1.UserService;
import com.spring.lesson1.Woman;

@SuppressWarnings("resource")
public class SpringTest{
	
	@Test
	public void test() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		Person person = context.getBean(Person.class);
		System.out.println(person.toString());
		
	}
	
	@Test
	public void testConfiguration() {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MyConfiguration.class);
		Person bean = applicationContext.getBean(Person.class);
		System.out.println(bean);
		
	}
	
	@Test
	public void test2() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		User user = context.getBean("user", User.class);
		System.out.println(user.hashCode());
		
		User user2 = context.getBean("user2", User.class);
		System.out.println(user2.hashCode());
		
		System.out.println(user == user2);
	}
	
	@Test
	public void test3() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		User user = context.getBean("user3", User.class);
		System.out.println(user);
		
		Person person = context.getBean(Person.class);
		System.out.println(person.toString());
	}
	
	@Test
	public void test4() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		User user = context.getBean("user4", User.class);
		System.out.println(user);
	}
	
	@Test
	public void test5() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		Man man = context.getBean("man", Man.class);
		System.out.println(man.toString());
		
		Man man2 = context.getBean("man2", Man.class);
		System.out.println(man2.toString());
	}
	
	@Test
	public void test6() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		Woman woman = context.getBean("woman", Woman.class);
		System.out.println(woman.toString());
		
	}
	
	@Test
	public void test7() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		Woman woman = context.getBean("woman2", Woman.class);
		System.out.println(woman.toString());
		
	}
	
	@Test
	public void test8() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring3.xml");
		Dog dog = context.getBean("dog", Dog.class);
		System.out.println(dog.toString());
		
	}
	
	@Test
	public void test9() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		Woman woman = context.getBean("woman2", Woman.class);
		System.out.println(woman.toString());
		
		UserService us = new UserService();
		us.setApplicationContext(context);
		User user = us.getUser();
		woman.setUser(user);
		System.out.println(woman.toString());
	}
	
	@Test
	public void test10() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml", "spring2.xml");
		User user = context.getBean("user5", User.class);
		System.out.println(user);
	}
	
	@Test
	public void test11() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		User user = context.getBean("user6", User.class);
		System.out.println(user);
	}
	
	@Test
	public void test12() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		User user = context.getBean("user7", User.class);
		System.out.println(user);
	}
}

	
