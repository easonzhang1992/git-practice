package com.designpatterns.strategy;

import org.junit.Test;

public class DiscountTest {

	@Test
	public void test() {
		Discount student = new StudentDiscount();
		MovieTicket ticket = new MovieTicket(50, student);
		int price = ticket.getDiscountPrice();
		System.out.println(price);
	}

}
