package com.designpatterns.singleton;

import org.junit.Test;

public class SingletonTest {

	@Test
	public void test() {
		Singleton singleton = Singleton.getInstance();
		Singleton singleton_1 = Singleton.getInstance();
		
		System.out.println(singleton == singleton_1);
		
		Singleton2 s2 = Singleton2.getInstance();
		Singleton2 s2_1 = Singleton2.getInstance();
		
		System.out.println(s2 == s2_1);
		
	}

}
