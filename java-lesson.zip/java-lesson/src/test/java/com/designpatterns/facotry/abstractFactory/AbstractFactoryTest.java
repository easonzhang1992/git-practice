package com.designpatterns.facotry.abstractFactory;

import org.junit.Test;

public class AbstractFactoryTest {

	@Test
	public void test() {
		SkinFactory sf = new SpringFactory();
		Button button = sf.createButton();
		TextField tf = sf.ceateTextField();
		
		button.display();
		tf.display();
	}

}
