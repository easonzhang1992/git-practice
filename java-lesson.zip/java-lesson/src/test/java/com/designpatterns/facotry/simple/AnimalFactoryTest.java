package com.designpatterns.facotry.simple;

import org.junit.Test;

public class AnimalFactoryTest {
	@Test
	public void test1() {
		Animal animal = AnimalFactory.getAnimal("dog");
		animal.eat();
		
		Animal animal2 = AnimalFactory.getAnimal("cat");
		animal2.eat();
	}
}
