package com.designpatterns.facotry.method;

import org.junit.Test;

public class LoggerFactoryTest {
	@Test
	public void test1() {
		LoggerFactory lf = new FileLoggerFactory();
		lf.writeLog("hello logger");
	}
}
