package com.designpatterns.builder;

import org.junit.Test;

public class BuilderTest {

	@Test
	public void test() {
		PersonBuilder pb = new PersonBuilder();
		Person person = pb.setdName("张三").setAge(20).setSex("男").setHobby("编程").build();
		System.out.println(person);
	}

}
