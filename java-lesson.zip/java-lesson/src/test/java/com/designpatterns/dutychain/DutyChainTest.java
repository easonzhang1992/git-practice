package com.designpatterns.dutychain;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class DutyChainTest {

	@Test
	public void test() {
		Request request = new Request(440, "手机");
		
		Saler saler = new Saler("张三");
		Manager manager = new Manager("李四");
		Boss boss = new Boss("王五");
		
		saler.setProcessor(manager);
		manager.setProcessor(boss);
		
		saler.doProcess(request);
		
	}
	
	@Test
	public void test2() {
		Request request = new Request(560, "手机");
		
		Saler saler = new Saler("张三");
		Manager manager = new Manager("李四");
		Boss boss = new Boss("王五");
		
		List<Processor> list = Arrays.asList(new Processor[] {saler, manager, boss});
		
		list.get(0).doProcess1(list, request, 0);
		
	}
}
