package com.designpatterns.bridge;

import org.junit.Test;

public class BridgerTest {

	@Test
	public void test() {
		FileType ft = new PdfFileType(new MySQLType());
		ft.convert();
		
		FileType ft2 = new PdfFileType(new DB2Type());
		ft2.convert();
		
		FileType ft3 = new TxtFileType(new MySQLType());
		ft3.convert();
		
		FileType ft4 = new TxtFileType(new DB2Type());
		ft4.convert();
		
	}

}
