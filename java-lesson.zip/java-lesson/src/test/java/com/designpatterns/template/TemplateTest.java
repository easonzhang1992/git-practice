package com.designpatterns.template;

import org.junit.Test;

public class TemplateTest {

	@Test
	public void test() {
		Treat treat = new NoodleTreat();
		treat.doTreat();
		
		System.out.println("--------------------------");
		
		Treat treat2 = new BeefTreat();
		treat2.doTreat();
	}

}
