package com.designpatterns.combination;

import org.junit.Test;

public class CombinationTest {

	@Test
	public void test() {
		AbstractFile img1 = new ImgFile("1");
		AbstractFile txt1 = new TxtFile("1");
		
		AbstractFile img2 = new ImgFile("2");
		AbstractFile txt2 = new TxtFile("2");
		Folder folder = new Folder("文件夹");
		folder.add(img2);
		folder.add(txt2);
		
		img1.operate();
		txt1.operate();
		System.out.println("======================");
		folder.operate();
		
	}

}
