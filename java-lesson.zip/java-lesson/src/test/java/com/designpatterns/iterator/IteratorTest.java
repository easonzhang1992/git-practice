package com.designpatterns.iterator;

import org.junit.Test;

public class IteratorTest {
	@Test
	public void test() {
		PersonList pl = new PersonList();
		pl.add("aa");
		pl.add("bb");
		pl.add("cc");
		
		Iterator<String> iter = pl.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
	}
}
