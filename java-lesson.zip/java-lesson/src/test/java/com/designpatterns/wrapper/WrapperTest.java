package com.designpatterns.wrapper;

import static org.junit.Assert.*;

import org.junit.Test;

public class WrapperTest {

	@Test
	public void test() {
		Encrypt encrypt1 = new Level1Encrypt();
		String res = encrypt1.operate();
		System.out.println(res);
		
		System.out.println("=============");
		Encrypt encrypt2 = new Level2Wapper(encrypt1);
		String result = encrypt2.operate();
		System.out.println(result);
	}

}
