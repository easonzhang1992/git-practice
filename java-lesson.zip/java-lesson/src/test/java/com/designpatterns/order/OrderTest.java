package com.designpatterns.order;

import org.junit.Test;

public class OrderTest {

	@Test
	public void test() {
		FBSettingWindow fbsw = new FBSettingWindow("功能键设置");
		FunctionButton fb = new FunctionButton("功能键1");
		HelpCommand command = new HelpCommand();
		fb.setCommand(command);
		
		fbsw.addFunctionButton(fb);
		fbsw.display();
		
		fb.onClick();
	}

}
