package com.hystrix;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.dubbo.rpc.RpcContext;

import com.dubbo.service.ProviderService;


/**
 * @author nnzhang
 */
public class DubboConsumerTest {

	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                new String[] { "applicationConsumer.xml" });  
          
        context.start();  
        ProviderService providerService = (ProviderService) context.getBean("providerService");
        for(int i=0; i<1; i++) {
	    	String result = providerService.sayHello("张南南");
	    	System.out.println(i + "  response from provider:" + RpcContext.getContext().getRemoteAddress());
	    	System.out.println("================================================");
	    	System.out.println("the result = " + result);
        }

	}

}
