package com.hystrix;

import java.util.concurrent.Future;

import org.junit.Test;

import com.dubbo.hystrix.CommandFailure;
import com.dubbo.hystrix.CommandHelloWorld;
import com.dubbo.hystrix.CommandThatFailsFast;
import com.dubbo.hystrix.CommandUsingRequestCache;
import com.dubbo.hystrix.ObCommandHelloWorld;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;

import rx.Observable;
import rx.observables.BlockingObservable;

public class GithubHystrixTest{
	
	//同步调用HystrixCommand
	@Test
	public void test1() {
		CommandHelloWorld command = new CommandHelloWorld("nnzhang");
		String result = command.execute();
		System.out.println("the result = " + result);
	}
	
	//异步调用HystrixCommand，Hystrix内部是起了两个线程，一个线程处理调用，另一个线程获取调用结果
	@Test
	public void test3() throws Exception {
		CommandHelloWorld command = new CommandHelloWorld("nnzhang");
		String result = command.queue().get();
		System.out.println("the result = " + result);
	}
	
	
	//异步调用HystrixObservableCommand，感觉写起来好繁琐
	@Test
	public void test2() throws Exception{
		ObCommandHelloWorld command = new ObCommandHelloWorld("nnzhang");
		Observable<String> observer = command.observe();
		
		BlockingObservable<String> blockingObservable = observer.toBlocking();
		Future<String> future = blockingObservable.toFuture();
		String result = future.get();//注意捕获异常
		
		System.out.println("the result = " + result);
	}
	
	@Test
	public void test4() throws Exception {
		CommandFailure command = new CommandFailure("nnzhang");
		String result = command.queue().get();
		System.out.println("the result = " + result);
	}
	
	
	@Test
	public void testIsRequestCacheHits() throws Exception {
		HystrixRequestContext context = HystrixRequestContext.initializeContext();
		try {
			CommandUsingRequestCache command = new CommandUsingRequestCache(2);
			CommandUsingRequestCache command1 = new CommandUsingRequestCache(2);
			Boolean res = command.execute();
			
			/**
			 * 下面这条命令这会从缓存中拿，原因有两个：
			 * 1.CommandUsingRequestCache类重写了getCacheKey()方法
			 * 2.和上一条command在同一个context里面
			 * 要想使缓存生效，两个条件缺一不可
			 */
			Boolean res1 = command1.execute(); 
			System.out.println("the result = " + res + ", isResponesFromCache = " + command.isResponseFromCache());
			System.out.println("the result1 = " + res1 + ", isResponesFromCache = " + command1.isResponseFromCache());
			
		}finally {
			context.shutdown();
		}
		
		HystrixRequestContext context2 = HystrixRequestContext.initializeContext();
		try {
			CommandUsingRequestCache command2 = new CommandUsingRequestCache(2);
			Boolean res2 = command2.execute(); //不会从缓存中拿，因为不在同一个context里面
			System.out.println("the result2 = " + res2 + ", isResponesFromCache = " + command2.isResponseFromCache());
			
		}finally {
			context2.shutdown();
		}
		
	}
	
	@Test
	public void testFailsFast(){
		try {
			CommandThatFailsFast command = new CommandThatFailsFast(true);
			String result = command.execute();
			System.out.println("the result = " + result);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}

	
