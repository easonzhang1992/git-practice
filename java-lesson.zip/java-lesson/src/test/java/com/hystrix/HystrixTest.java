package com.hystrix;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.Future;

import org.junit.Test;

import com.dubbo.hystrix.HelloWorldHystrixCommand;

public class HystrixTest{
	
	@Test
	public void test1() {
		System.out.println(new Date());
		HelloWorldHystrixCommand command = new HelloWorldHystrixCommand("nnzhang");
		Object result = command.execute();
		System.out.println("the result = " + result);
		System.out.println(new Date());
	}
	
	@Test
	public void test2() throws Exception {
		HelloWorldHystrixCommand command = new HelloWorldHystrixCommand("nnzhang");
		Future<String> future = command.queue();
		System.out.println(future.get());
	}
	
	@Test
    public void testSynchronous() throws Exception {
    	for(int i = 1; i < 50; i++) {
    		
    		Thread.sleep(500);
    		
    		HelloWorldHystrixCommand command = new HelloWorldHystrixCommand(String.valueOf(i));
    		String result = command.execute();
    		System.out.println(new Date() + " call time:" + i + " result = " + 
    		result + "  isCircuitBreakOpen:" + command.isCircuitBreakerOpen());
    		
    	}

    	System.out.println("------开始打印现有线程---------");
    	Map<Thread, StackTraceElement[]> map=Thread.getAllStackTraces();
    	for (Thread thread : map.keySet()) {
			System.out.println(thread.getName());
		}
    	System.out.println("thread num: " + map.size());
    	
    }
}

	
