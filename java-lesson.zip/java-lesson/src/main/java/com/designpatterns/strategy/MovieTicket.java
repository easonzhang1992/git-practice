package com.designpatterns.strategy;

public class MovieTicket {
	private int price;
	private Discount discount;

	public MovieTicket(int price, Discount discount) {
		this.price = price;
		this.discount = discount;
	}
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getDiscountPrice() {
		return discount.calculate(price);
	}
	
}
