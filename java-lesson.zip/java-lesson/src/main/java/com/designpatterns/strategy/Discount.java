package com.designpatterns.strategy;

// 打折接口
public interface Discount {
	int calculate(int initPrice);
}
