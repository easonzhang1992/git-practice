package com.designpatterns.strategy;

public class VIPDisCount implements Discount {
	@Override
	public int calculate(int initPrice) {
		// VIP票立减20元
		return (initPrice <= 20 ? initPrice : (initPrice - 20));
	}
}
