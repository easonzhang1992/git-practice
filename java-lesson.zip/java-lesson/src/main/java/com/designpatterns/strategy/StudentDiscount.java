package com.designpatterns.strategy;

public class StudentDiscount implements Discount {
	@Override
	public int calculate(int initPrice) {
		//学生票五折
		if(initPrice <=0) {
			throw new RuntimeException("价格错误");
		}
		return initPrice/2;
	}
}
