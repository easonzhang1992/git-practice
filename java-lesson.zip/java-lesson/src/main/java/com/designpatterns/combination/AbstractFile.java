package com.designpatterns.combination;

public interface AbstractFile {
	void operate();
}
