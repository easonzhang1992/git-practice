package com.designpatterns.combination;

public class ImgFile implements AbstractFile {
	private String name;
	public ImgFile(String name) {
		this.name = name;
	}

	@Override
	public void operate() {
		System.out.println("正在对图片文件" + this.name + "进行操作");
	}

}
