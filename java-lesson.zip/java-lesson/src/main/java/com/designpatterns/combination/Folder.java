package com.designpatterns.combination;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Folder implements AbstractFile {
	private List<AbstractFile> list = new ArrayList<AbstractFile>();
	private String name;
	
	public Folder(String name) {
		this.name = name;
	}
	
	public void add(AbstractFile file) {
		this.list.add(file);
	}

	public void remove(AbstractFile file) {
		this.list.remove(file);
	}

	public AbstractFile getChild(int i) {
		return this.list.get(i);
	}

	@Override
	public void operate() {
		System.out.println("正在递归对" + this.name + "进行操作");
		Iterator<AbstractFile> iter = list.iterator();
		while(iter.hasNext()) {
			iter.next().operate();
		}
	}
}
