package com.designpatterns.combination;

public class TxtFile implements AbstractFile {
	private String name;
	public TxtFile(String name) {
		this.name = name;
	}

	@Override
	public void operate() {
		System.out.println("正在对文本文件" + this.name + "进行操作");
	}

}
