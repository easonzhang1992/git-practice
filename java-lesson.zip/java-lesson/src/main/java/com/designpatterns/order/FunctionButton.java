package com.designpatterns.order;

public class FunctionButton {
	private String name;
	private Command command;
	public String getName() {
		return name;
	}
	public FunctionButton(String name) {
		this.name = name;
	}
	public void setCommand(Command command) {
		this.command = command;
	}
	
	public void onClick() {
		System.out.println("点击功能键：" + this.name);
		this.command.excute();
	}
	
	
	
}
