package com.designpatterns.order;

public class HelpCommand extends Command {
	private HelpHandler hp;
	
	public HelpCommand() {
		hp = new HelpHandler();
	}
	
	@Override
	public void excute() {
		hp.display();
	}

}
