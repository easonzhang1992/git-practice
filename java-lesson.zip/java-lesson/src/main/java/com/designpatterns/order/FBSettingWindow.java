package com.designpatterns.order;

import java.util.ArrayList;
import java.util.List;

public class FBSettingWindow {
	private String title; //窗口标题
	private List<FunctionButton> fbs = new ArrayList<FunctionButton>();  //该窗口所有的功能键集合
	
	public FBSettingWindow(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void addFunctionButton(FunctionButton fb) {
		this.fbs.add(fb);
	}
	
	public void removeFunctionButton(FunctionButton fb) {
		this.fbs.remove(fb);
	}
	
	public void display() {
		System.out.println("显示窗口：" + this.title);
		System.out.println("显示功能键：");
		for (Object obj : fbs) {
			System.out.println(((FunctionButton)obj).getName());
		}
		System.out.println("------------------------------");
	}
}
