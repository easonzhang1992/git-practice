package com.designpatterns.order;

public abstract class Command {
	public abstract void excute();
}
