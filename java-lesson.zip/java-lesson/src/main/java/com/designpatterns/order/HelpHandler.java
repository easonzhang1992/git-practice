package com.designpatterns.order;

public class HelpHandler {
	public void display() {
		System.out.println("显示帮助文档");
		
	}
}
