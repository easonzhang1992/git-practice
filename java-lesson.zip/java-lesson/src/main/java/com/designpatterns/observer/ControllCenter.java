package com.designpatterns.observer;

import java.util.ArrayList;
import java.util.List;

public class ControllCenter {
	private String name;
	private List<Observer> list = new ArrayList<Observer>();
	
	public ControllCenter(String name) {
		System.out.println(name + "组件战队成功");
		System.out.println("---------------------");
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void join(Observer ob) {
		System.out.println(ob.getName() + "加入" + this.name + "战队");
		list.add(ob);
	}
	
	public void quit(Observer ob) {
		System.out.println(ob.getName() + "退出" + this.name + "战队");
		list.remove(ob);
	}
	
	public void notifyObserver(String name) {
		System.out.println(name + "紧急通知,我被攻击了，快来救我");
		for(Observer ob : list) {
			if(!ob.getName().equalsIgnoreCase(name)) {
				ob.help();
			}
		}
	}
	
}
