package com.designpatterns.observer;

public interface Observer {
	String getName();
	void setName(String name);
	void help();
	void beAttacked(ControllCenter cc);
}
