package com.designpatterns.builder;

public class PersonBuilder {
	private Person p = new Person();
	
	public PersonBuilder setdName(String name) {
		p.setName(name);
		return this;
	}
	
	public PersonBuilder setAge(int age) {
		p.setAge(age);
		return this;
	}
	
	public PersonBuilder setSex(String sex) {
		p.setSex(sex);
		return this;
	}
	
	public PersonBuilder setHobby(String hobby) {
		p.setHobby(hobby);
		return this;
	}
	
	public Person build() {
		return p;
	}
}
