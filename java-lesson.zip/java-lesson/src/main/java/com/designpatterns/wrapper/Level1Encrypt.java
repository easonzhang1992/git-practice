package com.designpatterns.wrapper;

public class Level1Encrypt implements Encrypt {

	@Override
	public String operate() {
		System.out.println("使用级别1加密算法");
		return "level_1";
	}

}
