package com.designpatterns.wrapper;

public class Level2Wapper implements Encrypt {
	private Encrypt encrypt;
	public Level2Wapper(Encrypt encrypt) {
		this.encrypt = encrypt;
	}

	@Override
	public String operate() {
		String result = this.encrypt.operate();
		System.out.println("使用二级加密算法加密");
		return "level_2 >>" + result;
	}

}
