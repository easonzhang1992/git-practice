package com.designpatterns.wrapper;

public interface Encrypt {
	String operate();
}
