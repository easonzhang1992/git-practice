package com.designpatterns.interview.bridge;

public abstract class Product {
	protected Coin coin;
	public Product(Coin coin) {
		this.coin = coin;
	}
	
	public abstract void doSomething();
	
}
