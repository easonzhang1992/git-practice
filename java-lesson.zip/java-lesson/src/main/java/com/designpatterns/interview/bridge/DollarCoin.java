package com.designpatterns.interview.bridge;


public class DollarCoin implements Coin {

	@Override
	public void print() {
		System.out.println("this is a dollarCoin");
	}

}
