package com.designpatterns.interview.bridge;

public interface Coin {
	void print();
}
