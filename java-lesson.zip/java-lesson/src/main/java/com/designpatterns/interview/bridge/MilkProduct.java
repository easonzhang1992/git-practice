package com.designpatterns.interview.bridge;

public class MilkProduct extends Product {

	public MilkProduct(Coin coin) {
		super(coin);
	}

	@Override
	public void doSomething() {
		coin.print();
		System.out.println("this is a milk");
	}

}
