package com.designpatterns.dutychain;

import java.util.List;

public class Boss extends Processor {

	public Boss(String name) {
		super(name);
	}

	@Override
	public void doProcess(Request request) {
		System.out.println("老板" + this.name + "已对商品" + request.getProductName() + "处理完成");
	}

	@Override
	public void doProcess1(List<Processor> list, Request request, int i) {
		System.out.println("老板" + this.name + "已对商品" + request.getProductName() + "处理完成");
	}
}
