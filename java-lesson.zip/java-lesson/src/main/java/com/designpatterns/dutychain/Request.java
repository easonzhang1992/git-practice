package com.designpatterns.dutychain;

public class Request {
	private int productPrice;
	private String productName;
	
	public Request() {}
	
	public Request(int productPrice, String productName) {
		super();
		this.productPrice = productPrice;
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductNumber(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Request [productPrice=" + productPrice + ", productName=" + productName + "]";
	}
}
