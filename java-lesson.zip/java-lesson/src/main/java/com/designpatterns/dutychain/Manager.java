package com.designpatterns.dutychain;

import java.util.List;

public class Manager extends Processor {

	public Manager(String name) {
		super(name);
	}

	@Override
	public void doProcess(Request request) {
		int price = request.getProductPrice();
		if(price < 0)
			throw new RuntimeException("价格不能小于零");
		else if(price < 100)
			System.out.println("经理" + this.name + "已对商品" + request.getProductName() + "处理完成");
		else {
			System.out.println("经理" + this.name + "没有权限处理，转交给下一个负责人处理");
			this.nextProcessor.doProcess(request);
		}
	}

	@Override
	public void doProcess1(List<Processor> list, Request request, int i) {
		int price = request.getProductPrice();
		if(price < 0)
			throw new RuntimeException("价格不能小于零");
		else if(price < 100)
			System.out.println("经理" + this.name + "已对商品" + request.getProductName() + "处理完成");
		else {
			System.out.println("经理" + this.name + "没有权限处理，转交给下一个负责人处理");
			if(i == list.size() -1 ) {
				//是最后一位处理者
				System.out.println("没有后续负责人可以处理，直接返回");
				return;
			}
			list.get(i+1).doProcess1(list, request, i+1);
		}
	}
}
