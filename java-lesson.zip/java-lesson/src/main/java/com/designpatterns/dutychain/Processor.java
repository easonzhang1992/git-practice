package com.designpatterns.dutychain;

import java.util.List;

public abstract class Processor {
	protected String name;
	protected Processor nextProcessor;
	
	public Processor(String name) {
		this.name = name;
	}
	
	public void setProcessor(Processor next) {
		this.nextProcessor = next;
	}
	
	public abstract void doProcess(Request request);
	
	public abstract void doProcess1(List<Processor> list, Request request, int i);
	
}
