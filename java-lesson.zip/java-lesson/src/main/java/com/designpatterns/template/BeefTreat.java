package com.designpatterns.template;

// 请吃牛肉
public class BeefTreat extends Treat {

	@Override
	public void eat() {
		System.out.println("正在吃牛肉");
	}

}
