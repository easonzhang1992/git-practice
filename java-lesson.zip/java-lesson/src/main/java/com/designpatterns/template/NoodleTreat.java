package com.designpatterns.template;

// 请吃面条
public class NoodleTreat extends Treat {

	@Override
	public void eat() {
		System.out.println("正在吃面条");
	}

}
