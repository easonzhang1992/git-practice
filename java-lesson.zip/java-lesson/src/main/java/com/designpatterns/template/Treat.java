package com.designpatterns.template;

// 请客类
public abstract class Treat {
	private void findPlace() {
		System.out.println("已找到饭店");
	}
	public abstract void eat();
	private void pay() {
		System.out.println("吃完了，已付账");
	} 
	public void doTreat() {
		findPlace();
		eat();
		pay();
	}
}
