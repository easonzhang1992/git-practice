package com.designpatterns.facotry.method;

public interface Logger {
	void writeLog(String message);
}
