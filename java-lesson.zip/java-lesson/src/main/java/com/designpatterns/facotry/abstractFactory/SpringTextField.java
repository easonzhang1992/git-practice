package com.designpatterns.facotry.abstractFactory;

public class SpringTextField implements TextField {

	@Override
	public void display() {
		System.out.println("the springTextField displsy");
	}

}
