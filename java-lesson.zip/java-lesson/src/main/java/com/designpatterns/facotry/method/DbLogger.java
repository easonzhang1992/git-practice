package com.designpatterns.facotry.method;

public class DbLogger implements Logger {
	@Override
	public void writeLog(String message) {
		System.out.println("the DbLogger print " + message);
	}
}
