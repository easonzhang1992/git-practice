package com.designpatterns.facotry.abstractFactory;

public class SummerButton implements Button {

	@Override
	public void display() {
		System.out.println("the summerButton displsy");
	}

}
