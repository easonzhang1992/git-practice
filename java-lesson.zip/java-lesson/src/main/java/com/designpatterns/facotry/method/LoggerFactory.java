package com.designpatterns.facotry.method;

public abstract class LoggerFactory {
	
	public abstract Logger getLogger();
	
	public void writeLog(String message) {
		Logger log = this.getLogger();
		log.writeLog(message);
	}

}
