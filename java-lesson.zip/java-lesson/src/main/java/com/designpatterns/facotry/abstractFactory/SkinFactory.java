package com.designpatterns.facotry.abstractFactory;

public interface SkinFactory {
	Button createButton(); //创建按钮
	TextField ceateTextField(); //创建文本框
}
