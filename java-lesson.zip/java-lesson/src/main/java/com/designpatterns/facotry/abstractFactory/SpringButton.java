package com.designpatterns.facotry.abstractFactory;

public class SpringButton implements Button {

	@Override
	public void display() {
		System.out.println("the springButton displsy");
	}
	
}
