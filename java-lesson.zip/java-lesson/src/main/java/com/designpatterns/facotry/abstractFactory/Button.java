package com.designpatterns.facotry.abstractFactory;

public interface Button {
	void display();
}
