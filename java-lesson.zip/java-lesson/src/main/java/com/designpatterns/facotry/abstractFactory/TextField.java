package com.designpatterns.facotry.abstractFactory;

public interface TextField {
	void display();
}
