package com.designpatterns.facotry.simple;

public class Cat implements Animal {
	@Override
	public void eat() {
		System.out.println("the cat is eating");
	}

}
