package com.designpatterns.facotry.abstractFactory;

public class SummerFactory implements SkinFactory {

	@Override
	public Button createButton() {
		return new SummerButton();
	}

	@Override
	public TextField ceateTextField() {
		return new SummerTextField();
	}

}
