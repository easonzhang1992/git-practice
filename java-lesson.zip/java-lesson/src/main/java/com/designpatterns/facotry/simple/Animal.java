package com.designpatterns.facotry.simple;

public interface Animal {
	void eat();
}
