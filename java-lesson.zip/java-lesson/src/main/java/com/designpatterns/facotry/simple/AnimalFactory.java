package com.designpatterns.facotry.simple;

public class AnimalFactory{
	private static Dog dog = new Dog();
	private static Cat cat = new Cat();
	public static Animal getAnimal(String name) {
		if("dog".equals(name)) {
			return dog;
		}else if("cat".equals(name)) {
			return cat;
		}else
			throw new RuntimeException("the type " + name + "is not supported");
	}
}
