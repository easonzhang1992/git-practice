package com.designpatterns.facotry.abstractFactory;

public class SummerTextField implements TextField {

	@Override
	public void display() {
		System.out.println("the summerTextField displsy");
	}

}
