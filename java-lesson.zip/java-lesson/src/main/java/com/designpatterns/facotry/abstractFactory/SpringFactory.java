package com.designpatterns.facotry.abstractFactory;

public class SpringFactory implements SkinFactory {

	@Override
	public Button createButton() {
		return new SpringButton();
	}

	@Override
	public TextField ceateTextField() {
		return new SpringTextField();
	}
	
}
