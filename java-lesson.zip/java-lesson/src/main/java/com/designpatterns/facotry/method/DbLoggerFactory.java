package com.designpatterns.facotry.method;

public class DbLoggerFactory extends LoggerFactory {

	@Override
	public Logger getLogger() {
		return new FileLogger();
	}

}
