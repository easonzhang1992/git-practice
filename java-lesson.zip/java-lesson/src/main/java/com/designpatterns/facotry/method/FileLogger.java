package com.designpatterns.facotry.method;

public class FileLogger implements Logger {
	@Override
	public void writeLog(String message) {
		System.out.println("the fileLogger print " + message);
	}
}
