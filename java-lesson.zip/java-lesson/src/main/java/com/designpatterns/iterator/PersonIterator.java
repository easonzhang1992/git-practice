package com.designpatterns.iterator;

import java.util.List;

public class PersonIterator<T> implements Iterator<T> {
	private PersonList list;
	private int cursor = 0;
	
	public PersonIterator(PersonList list){
		this.list = list;
	}

	@Override
	public boolean hasNext() {
		List<String> tmp = list.getList();
		return cursor < tmp.size();
	}

	@Override
	public String next() {
		List<String> tmp = list.getList();
		if(cursor == tmp.size()) {
			throw new RuntimeException("已经是最后一个数据啦~~~");
		}
		return tmp.get(cursor++);
	}
	
}
