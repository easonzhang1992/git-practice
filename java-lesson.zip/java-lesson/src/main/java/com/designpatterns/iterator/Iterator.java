package com.designpatterns.iterator;

public interface Iterator<T> {
	boolean hasNext();
	String next();
}
