package com.designpatterns.iterator;

import java.util.ArrayList;
import java.util.List;

public class PersonList {
	private List<String> list = new ArrayList<String>();
	
	public void add(String name) {
		list.add(name);
	}
	
	public List<String> getList() {
		return list;
	}
	
	public PersonIterator<String> iterator() {
		return new PersonIterator<String>(this);
	}
	
}
