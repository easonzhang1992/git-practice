package com.designpatterns.bridge;

public class DB2Type implements DBType {

	@Override
	public void print() {
		System.out.print("from DB2 ");
	}

}
