package com.designpatterns.bridge;

public class PdfFileType extends FileType {

	public PdfFileType(DBType dbType) {
		super(dbType);
	}

	@Override
	public void convert() {
		dbType.print();
		System.out.println("convert to pdf");
	}
	
	
}
