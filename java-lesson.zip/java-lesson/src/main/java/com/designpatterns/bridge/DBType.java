package com.designpatterns.bridge;

public interface DBType {
	void print();
}
