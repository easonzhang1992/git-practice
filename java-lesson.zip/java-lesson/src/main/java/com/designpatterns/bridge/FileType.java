package com.designpatterns.bridge;

public abstract class FileType {
	protected DBType dbType;
	protected FileType(DBType dbType) {
		this.dbType = dbType;
	}
	public abstract void convert();
}
