package com.designpatterns.bridge;

public class MySQLType implements DBType {

	@Override
	public void print() {
		System.out.print("from MySQL ");
	}
	
}
