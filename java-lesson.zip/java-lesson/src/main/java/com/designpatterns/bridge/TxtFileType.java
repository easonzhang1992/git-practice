package com.designpatterns.bridge;

public class TxtFileType extends FileType {

	public TxtFileType(DBType dbType) {
		super(dbType);
	}

	@Override
	public void convert() {
		dbType.print();
		System.out.println("convert to txt");
	}
}
