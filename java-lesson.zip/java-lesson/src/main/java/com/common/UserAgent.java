package com.common;

public enum UserAgent {

    CHROME("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.119 Safari/537.36");

    String NAME;
    String VALUE;

    UserAgent(String NAME, String VALUE) {
        this.NAME = NAME;
        this.VALUE = VALUE;
    }

}
