package com.common;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GeneratorDownloadURL {

//    private static final String URL = "http://open.163.com/special/opencourse/algorithms.html";
    private static final String URL = "http://open.163.com/special/Khan/finance.html";
    private static final String COMMAND_PREFIX = "you-get";

    public static void main(String[] args) throws IOException {
        Document document = Jsoup.connect(URL)
                .header(UserAgent.CHROME.NAME, UserAgent.CHROME.VALUE)
                .get();
        Elements list = document.body().getElementById("list2").getElementsByClass("u-ctitle");
        for (int i = 0; i < list.size(); i++) {
            Element element = list.get(i);
            String fileName = element.text().trim();
            Elements a = element.getElementsByTag("a");
            String href = a.get(0).attr("href").trim();
            String s = COMMAND_PREFIX + " " + "-O" + " " + fileName + " " + href;
            System.out.println(s);
        }
    }


}
