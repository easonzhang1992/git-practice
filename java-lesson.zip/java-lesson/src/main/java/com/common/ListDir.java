package com.common;

import java.io.File;

public class ListDir {

    public static void main(String[] args) {

        File file = new File("G:\\极客时间");
        File[] files = file.listFiles();
        for(File f : files) {
            System.out.println(f.getName());
        }

    }
}
