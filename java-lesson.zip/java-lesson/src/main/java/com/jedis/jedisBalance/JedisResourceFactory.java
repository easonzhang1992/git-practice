package com.jedis.jedisBalance;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.BinaryJedis;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisDataException;

class JedisResourceFactory implements PooledObjectFactory<Jedis> {
	private static final Logger logger = LoggerFactory.getLogger(JedisResourceFactory.class);

	private final AtomicReference<HostAndPort> hostAndPort = new AtomicReference<HostAndPort>();
	private final int timeout;
	private String password;
	private final int database;
	private final String clientName;

	private boolean needUpdatePwd = false;
	private Object updatePwdLock = new Object();

	private AtomicInteger createCount = new AtomicInteger(0);
	private AtomicInteger destroyCount = new AtomicInteger(0);

	public JedisResourceFactory(final String host, final int port,
			final int timeout, final String password, final int database) {
		this(host, port, timeout, password, database, null);
	}

	public JedisResourceFactory(final String host, final int port,
			final int timeout, final String password, final int database,
			final String clientName) {
		super();
		this.hostAndPort.set(new HostAndPort(host, port));
		this.timeout = timeout;
		this.password = password;
		this.database = database;
		this.clientName = clientName;
	}

	public void setHostAndPort(final HostAndPort hostAndPort) {
		this.hostAndPort.set(hostAndPort);
	}

	@Override
	public void activateObject(PooledObject<Jedis> pooledJedis)
			throws Exception {
		final BinaryJedis jedis = pooledJedis.getObject();
		if (jedis.getDB() != database) {
			jedis.select(database);
		}

	}

	@Override
	public void destroyObject(PooledObject<Jedis> pooledJedis) throws Exception {
		final BinaryJedis jedis = pooledJedis.getObject();
		logger.info("jedis destroy count: " + destroyCount.addAndGet(1));
		if (jedis.isConnected()) {
			try {
				try {
					jedis.quit();
				} catch (Exception e) {
				}
				jedis.disconnect();
			} catch (Exception e) {

			}
		}

	}

	@Override
	public PooledObject<Jedis> makeObject() throws Exception {
		final HostAndPort hostAndPort = this.hostAndPort.get();
		final Jedis jedis = new Jedis(hostAndPort.getHost(),
				hostAndPort.getPort(), this.timeout);

		jedis.connect();
		if (null != this.password) {
			try {
				jedis.auth(this.password);
			} catch (JedisDataException e) {
				// auth failed
				needUpdatePwd = true;
				logger.error("Auth failed, maybe password " + password
						+ " is overdue.");
				fetchNewPassword();
				logger.info("New password is " + password);
				jedis.auth(this.password);
			}
		}
		if (database != 0) {
			jedis.select(database);
		}
		if (clientName != null) {
			jedis.clientSetname(clientName);
		}
		logger.info("jedis create count: " + createCount.addAndGet(1));
		return new DefaultPooledObject<Jedis>(jedis);
	}

	private void fetchNewPassword() throws Exception {
		if (needUpdatePwd) {
			synchronized (updatePwdLock) {
				if (needUpdatePwd) {
					this.password = "";
					needUpdatePwd = false;
				}
			}
		}
	}

	@Override
	public void passivateObject(PooledObject<Jedis> pooledJedis)
			throws Exception {
		// TODO maybe should select db 0? Not sure right now.
	}

	@Override
	public boolean validateObject(PooledObject<Jedis> pooledJedis) {
		final BinaryJedis jedis = pooledJedis.getObject();
		try {
			HostAndPort hostAndPort = this.hostAndPort.get();

			String connectionHost = jedis.getClient().getHost();
			int connectionPort = jedis.getClient().getPort();

			return hostAndPort.getHost().equals(connectionHost)
					&& hostAndPort.getPort() == connectionPort
					&& jedis.isConnected() && jedis.ping().equals("PONG");
		} catch (final Exception e) {
			return false;
		}
	}
}
