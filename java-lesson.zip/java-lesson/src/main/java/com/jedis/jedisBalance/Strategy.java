package com.jedis.jedisBalance;

public enum Strategy {
	roundRobin, weightedRoundRobin, traffic
}
