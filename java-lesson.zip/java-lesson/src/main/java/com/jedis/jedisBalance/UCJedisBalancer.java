package com.jedis.jedisBalance;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import redis.clients.jedis.JedisPoolConfig;

@Repository
public class UCJedisBalancer {
	private static JedisBalancer instance = null;

//	@Config(ParaCfgConst.REDIS_ADDRS)
	private static String redisAddrs;

//	@Config(ParaCfgConst.REDIS_MAX_CONN)
	private static Integer redisMaxConn = 500;

//	@Config(ParaCfgConst.REDIS_MAX_IDLE)
	private static Integer redisMaxIdle = 200;

//	@Config(ParaCfgConst.REDIS_POOL_TIMEOUT)
	private static Integer redisPoolTimeout = 1000;

//	@Config(ParaCfgConst.REDIS_TIMEOUT)
	private static Integer redisTimeout = 1000;

//	@Config(ParaCfgConst.REDIS_NEED_AUTH)
	private static String redisNeedAuth = "1";

	public JedisBalancer getInstance() {
		if (instance == null) {
			synchronized (UCJedisBalancer.class) {
				if (instance == null) {
					initSelf();
				}
			}
		}
		return instance;
	}

	private void initSelf() {
		JedisBalancer _instance = JedisBalancer.getInstance();
		JedisPoolConfig config = new JedisPoolConfig();
		config.setTestOnBorrow(true);
		config.setMaxTotal(redisMaxConn);
		config.setMaxIdle(redisMaxIdle);
		config.setMaxWaitMillis(redisPoolTimeout);
		_instance.setConfig(config);
		_instance.setJedisTimeout(redisTimeout);

		if (StringUtils.isBlank(redisAddrs))
			throw new RuntimeException("redis地址未配置");

		String[] addrs = redisAddrs.split(",");
		for (String addr : addrs) {
			String[] ipPort = addr.split(":");
			if (ipPort.length != 2)
				throw new RuntimeException("redis地址配置有误：" + ipPort);

			boolean needAuth = "1".equals(redisNeedAuth);
			// 密码传null则不会启动dbpm功能
			_instance.addMember(ipPort[0], Integer.valueOf(ipPort[1]),
					needAuth ? "12345678" : null);
		}
		instance = _instance;
	}
}
