package com.jedis.jedisBalance;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Protocol;
import redis.clients.jedis.exceptions.JedisException;
import redis.clients.util.Pool;

public class JedisResourcePool extends Pool<Jedis> {

	public JedisResourcePool(GenericObjectPoolConfig poolConfig, String host,
			int port, String password, int timeout) {
		super(poolConfig, new JedisResourceFactory(host, port, timeout,
				password, Protocol.DEFAULT_DATABASE, null));
	}

	/**
	 * Clear and destroy idle pooledObject.
	 */
	public void clear() {
		internalPool.clear();
	}

	@Override
	public Jedis getResource() {
		Jedis jedis = super.getResource();
		jedis.setDataSource(this);
		return jedis;
	}

	public void returnBrokenResource(final Jedis resource) {
		if (resource != null) {
			returnBrokenResourceObject(resource);
		}
	}

	public void returnResource(final Jedis resource) {
		if (resource != null) {
			try {
				resource.resetState();
				returnResourceObject(resource);
			} catch (Exception e) {
				returnBrokenResource(resource);
				throw new JedisException(
						"Could not return the resource to the pool", e);
			}
		}
	}

	@Override
	public int getNumActive() {
		if (this.internalPool == null || this.internalPool.isClosed()) {
			return -1;
		}

		return this.internalPool.getNumActive();
	}
}
