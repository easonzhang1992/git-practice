package com.jedis.jedisBalance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisException;

public class JedisBalancer {
	private static final Logger logger = LoggerFactory.getLogger(JedisBalancer.class);

	private Thread checkThread = null;// 用于检测连接的线程
	private boolean isChecking = false;
	private boolean isMovingPool = false;

	private Map<String, Integer> weights = new ConcurrentHashMap();
	private Map<String, JedisResourcePool> validPools = new ConcurrentHashMap();

	private Map<String, JedisResourcePool> invalidPools = new ConcurrentHashMap();

	private Map<Jedis, JedisResourcePool> usedResource = new ConcurrentHashMap();// 由于Jedis对象没有关于其所在的pool信息，因此定义该映射，记录Jedis与pool的关系

	private AtomicInteger count = new AtomicInteger(0);// 调用计数，用于轮询负载

	private List<String> keys = Collections.synchronizedList(new ArrayList());// 用于轮询负载
	private List<String> weightedKeys = Collections
			.synchronizedList(new ArrayList());// 用于加权轮询负载

	private Strategy strategy = Strategy.roundRobin;
	private JedisPoolConfig config;
	// redis连接超时时间 && redis应答响应时间（ms）
	private int redisTimeout = 1000;

	private static final String REGEX_IP = "^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$";

	private JedisBalancer() {
		ConnnectionChecker checker = new ConnnectionChecker();
		checker.setInterval(5000);
		checkThread = new Thread(checker, "jedis-checker");
		checkThread.start();
		logger.info("JedisBalancer start");
	}

	public static JedisBalancer getInstance() {
		return new JedisBalancer();
	}

	/** 本方法须在添加负载节点之前调用 */
	public void setStrategy(Strategy strategy) {
		this.strategy = strategy;
	}

	public void setConfig(JedisPoolConfig config) {
		this.config = config;
		if (config != null) {
            logger.info("Jedis config: maxTotal=" + config.getMaxTotal()
                    + ", maxIdle=" + config.getMaxIdle() + ", maxWaitMillis="
                    + config.getMaxWaitMillis());
        }
	}

	public void setJedisTimeout(int redisTimeout) {
		this.redisTimeout = redisTimeout;
		logger.info("Jedis soTimeout:" + redisTimeout);
	}

	public boolean addMember(String host, int port, String password) {
		return addMember(host, port, password, 1);
	}

	public boolean addMember(String host, int port, String password, int weight) {
		logger.info("Add member " + host + ":" + port);

		if (host == null || !host.matches(REGEX_IP)) {
            return false;
        }

		weights.put(key(host, port), weight);

		if (config == null) {
			config = new JedisPoolConfig();
			config.setTestOnBorrow(true);
			config.setTestOnReturn(true);
		}
		JedisResourcePool pool = new JedisResourcePool(config, host, port,
				password, redisTimeout);
		boolean valid = checkPool(pool);

		logger.info("Member " + host + ":" + port
				+ (valid ? " is valid." : " is not valid."));
		if (valid) {
			addValidPool(key(host, port), pool);
		} else {
			addInvalidPool(key(host, port), pool);
		}
		return valid;
	}

	public boolean removeMember(String host, int port) {
		logger.info("Remove member " + host + ":" + port);

		if (host == null || !host.matches(REGEX_IP)) {
            return false;
        }

		String key = key(host, port);
		weights.remove(key);

		if (validPools.containsKey(key)) {
			removeValidPool(key);
		}
		if (invalidPools.containsKey(key)) {
			removeInvalidPool(key);
		}
		return true;
	}

	private String key(String host, int port) {
		return host + ":" + port;
	}

	public Jedis getResource() {
		return _getResource(0);
	}

	private Jedis _getResource(int tryTimes) {
		if (tryTimes >= 3) {
            throw new RuntimeException("Try too many times to connect redis");
        }

		while (isMovingPool) {
			threadSleep(10);
		}

		String key = getBalancedKey();
		if (key == null) {
            throw new RuntimeException("There's no valid pool.");
        }

		JedisResourcePool pool = validPools.get(key);
		if (pool == null) {// keys与validPools不同步，小概率事件
            return _getResource(++tryTimes);
        }
		Jedis resource = null;
		try {
			resource = pool.getResource(); // pool将对新的resource做连接检查，因此得到的resource保证是可用的
		} catch (JedisConnectionException e) {
			// 连接异常处理
			checkThread.interrupt();
			while (isChecking) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e1) {
				}
			}
			return _getResource(++tryTimes);
		}

		usedResource.put(resource, pool);
		return resource;
	}

	public void returnResource(final Jedis resource) {
		if (resource == null) {
            return;
        }

		try {
			JedisResourcePool pool = usedResource.get(resource);
			usedResource.remove(resource);
			pool.returnResource(resource);
		} catch (Exception e) {
			throw new JedisException(
					"Could not return the resource to the pool", e);
		}
	}

	public void returnBrokenResource(final Jedis resource) {
		if (resource == null) {
            return;
        }

		try {
			JedisResourcePool pool = usedResource.get(resource);
			usedResource.remove(resource);
			if (pool != null) {
                pool.returnBrokenResource(resource);
            }
		} catch (Exception e) {
			throw new JedisException(
					"Could not return the resource to the pool", e);
		}
	}

	/** 根据负载策略，确定下一个连接池的key */
	private String getBalancedKey() {
		int currentCount = count.getAndAdd(1);
		if (currentCount < 0) {
            currentCount = ~currentCount;
        }

		String key = null;
		if (strategy.equals(Strategy.roundRobin)) {
			if (keys.size() == 0) {
				return null;
			} else {
				key = keys.get(currentCount % keys.size());
			}

		} else if (strategy.equals(Strategy.weightedRoundRobin)) {
			if (weightedKeys.size() == 0) {
				return null;
			} else {
				key = weightedKeys.get(currentCount % weightedKeys.size());
			}

		} else {
			throw new RuntimeException("不支持的strategy类型");
		}

		return key;
	}

	/** Jedis连接检查器 */
	private class ConnnectionChecker implements Runnable {
		private long interval = 5000;

		public void setInterval(long interval) {
			this.interval = interval;
		}

		@Override
		public void run() {
			while (true) {
				try {
					isChecking = true;
					checkValidPools();
					checkInvalidPools();
					isChecking = false;
					try {
						Thread.sleep(interval);
					} catch (InterruptedException e) {
						logger.info("checker interrupted");
					}
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	private void checkValidPools() {
		Iterator<Entry<String, JedisResourcePool>> it = validPools.entrySet()
				.iterator();
		Map<String, JedisResourcePool> invalids = new HashMap();

		while (it.hasNext()) {
			Entry<String, JedisResourcePool> entry = it.next();
			String key = entry.getKey();
			JedisResourcePool pool = entry.getValue();

			boolean valid = checkPool(pool);
			if (valid) {
                continue;
            }

			invalids.put(key, pool);
		}

		for (String key : invalids.keySet()) {
			logger.info("Jedis pool invalid: " + key);
			addInvalidPool(key, invalids.get(key));
			removeValidPool(key);
			invalids.get(key).clear();
		}
	}

	private void checkInvalidPools() {
		Iterator<Entry<String, JedisResourcePool>> it = invalidPools.entrySet()
				.iterator();
		Map<String, JedisResourcePool> valids = new HashMap();

		while (it.hasNext()) {
			Entry<String, JedisResourcePool> entry = it.next();
			String key = entry.getKey();
			JedisResourcePool pool = entry.getValue();

			boolean valid = checkPool(pool);
			if (!valid) {
                continue;
            }

			valids.put(key, pool);
		}

		for (String key : valids.keySet()) {
			logger.info("Jedis pool valid: " + key);
			valids.get(key).clear();
			addValidPool(key, valids.get(key));
			removeInvalidPool(key);
		}
	}

	private boolean checkPool(JedisResourcePool pool) {
		for (int i = 0; i < 3; i++) {
			Jedis jedis = null;
			try {
				jedis = pool.getResource();
			} catch (JedisConnectionException e) {
				threadSleep(50);
				continue;
			}

			try {
				if (checkJedis(jedis)) {
					pool.returnResource(jedis);
					return true;
				} else {
					pool.returnBrokenResource(jedis);
					threadSleep(50);
					continue;
				}
			} catch (JedisConnectionException e) {
				pool.returnBrokenResource(jedis);
				threadSleep(50);
				continue;
			}
		}
		// 如果尝试三次都失败，则认为该连接池失效
		return false;
	}

	private void threadSleep(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e1) {
		}
	}

	private boolean checkJedis(Jedis jedis) {
		return "PONG".equals(jedis.ping());
	}

	private synchronized void addValidPool(String key, JedisResourcePool pool) {
		isMovingPool = true;
		keys.add(key);
		for (int i = 0; i < weights.get(key); i++) {
			weightedKeys.add(key);
		}
		validPools.put(key, pool);
		isMovingPool = false;
	}

	private synchronized void removeValidPool(String key) {
		isMovingPool = true;
		keys.remove(key);
		for (int i = 0; i < weights.get(key); i++) {
			weightedKeys.remove(key);
		}
		validPools.remove(key);
		isMovingPool = false;
	}

	private void addInvalidPool(String key, JedisResourcePool pool) {
		invalidPools.put(key, pool);
	}

	private void removeInvalidPool(String key) {
		invalidPools.remove(key);
	}

}
