package com.jedis;

public class JedisMain {
}
