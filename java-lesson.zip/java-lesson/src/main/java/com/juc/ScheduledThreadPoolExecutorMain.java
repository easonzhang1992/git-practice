package com.juc;

import java.util.Date;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ScheduledThreadPoolExecutorMain {

    public static void main(String[] args) {

        ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(
                1,new MyThreadFacotry(), new ThreadPoolExecutor.AbortPolicy());

        //在线程池关闭时，后续的周期任务要不要继续执行，默认为false，也就是线程池关闭时，不再执行周期任务
        executor.setContinueExistingPeriodicTasksAfterShutdownPolicy(false);


        //关闭后继续执行已经存在的延时任务
        executor.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);

        //取消任务后移除所有任务
        executor.setRemoveOnCancelPolicy(true);


        //延迟delay时间后开始执行任务,只会执行一次
//        executor.schedule(new RunTask(), 2, TimeUnit.SECONDS);


        // 延迟initialDelay时间后开始执行command，并且按照period时间周期性重复调用，
        // 当任务执行时间大于间隔时间时，之后的任务都会延迟
//        executor.scheduleAtFixedRate(new RunTask(), 2, 3, TimeUnit.SECONDS);


        //延迟initialDelay时间后开始执行command，并且按照period时间周期性重复调用，
        // 这里的间隔时间delay是等上一个任务完全执行完毕才开始计算
        executor.scheduleWithFixedDelay(new RunTask(), 0, 3, TimeUnit.SECONDS);

        try {
            Thread.sleep(5000);
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        /**
         * 将线程池状态置为SHUTDOWN,并不会立即停止：
         * 1、停止接收外部submit的任务
         * 2、内部正在跑的任务和队列里等待的任务，会执行完
         * 3、等到第二步完成后，才真正停止
         */
        executor.shutdown();

        /**
         * 将线程池状态置为STOP。企图立即停止，事实上不一定：
         * 1、跟shutdown()一样，先停止接收外部提交的任务
         * 2、忽略队列里等待的任务
         * 3、尝试将正在跑的任务interrupt中断
         * 4、返回未执行的任务列表
         */

        /**
         * 它试图终止线程的方法是通过调用Thread.interrupt()方法来实现的，但这种方法的作用有限，
         * 如果线程中没有sleep 、wait、Condition、定时锁等应用, interrupt()方法是无法中断当前的线程的。
         * 所以，ShutdownNow()并不代表线程池就一定立即就能退出，它也可能必须要等待所有正在执行的任务都执行完成了才能退出。
         * 但是大多数时候是能立即退出的
         */
        executor.shutdownNow();


        /**
         * 当前线程阻塞，直到：
         * 1、等所有已提交的任务（包括正在跑的和队列中等待的）执行完
         * 2、或者等超时时间到
         * 3、或者线程被中断，抛出InterruptedException
         * 然后返回true（shutdown请求后所有任务执行完毕）或false（已超时）
         */
        try {
            executor.awaitTermination(5, TimeUnit.SECONDS);
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        /**
         * shutdown()和shutdownNow()的区别:
         *
         * 从字面意思就能理解，shutdownNow()能立即停止线程池，正在跑的和正在等待的任务都停下了。这样做立即生效，但是风险也比较大；
         * shutdown()只是关闭了提交通道，用submit()是无效的；而内部该怎么跑还是怎么跑，跑完再停。
         */

        /**
         * shutdown()和awaitTermination()的区别:
         *
         * shutdown()后，不能再提交新的任务进去；但是awaitTermination()后，可以继续提交。
         * awaitTermination()是阻塞的，返回结果是线程池是否已停止（true/false）；shutdown()不阻塞
         */

        /**
         * 总结：
         *
         * 优雅的关闭，用shutdown()
         * 想立马关闭，并得到未执行任务列表，用shutdownNow()
         * 优雅的关闭，并允许关闭声明后新任务能提交，用awaitTermination()
         * 关闭功能 【从强到弱】 依次是：shuntdownNow() > shutdown() > awaitTermination()
         *
         * 参考链接：https://blog.csdn.net/u012168222/article/details/52790400
         */

        /**
         * shutdown和awaitTermination为接口ExecutorService定义的两个方法，一般情况配合使用来关闭线程池。
         *
         * shutdown方法：平滑的关闭ExecutorService，当此方法被调用时，
         * ExecutorService停止接收新的任务并且等待已经提交的任务（包含提交正在执行和提交未执行）执行完成。
         * 当所有提交任务执行完毕，线程池即被关闭。
         *
         * awaitTermination方法：接收人timeout和TimeUnit两个参数，用于设定超时时间及单位。
         * 当等待超过设定时间时，会监测ExecutorService是否已经关闭，若关闭则返回true，否则返回false。
         *
         * 一般情况下会和shutdown方法组合使用。
         *
         * executor.shutdown(); //调用该方法后，如果某个任务执行时间很长，在该任务执行期间内线程池不会关闭的
         * executor.awaitTermination(10, TimeUnit.SECONDS); //不管线程池当前有没有关闭，10秒必须关闭掉，
         */

    }


    static class RunTask implements Runnable {

        @Override
        public void run() {
            System.out.println(new Date() + "  run task");
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
    }

    static class MyThreadFacotry implements ThreadFactory {

        @Override
        public Thread newThread(Runnable r) {
            Thread thread = new Thread(r);
            thread.setName("my-thread");
            return thread;
        }
    }

}
