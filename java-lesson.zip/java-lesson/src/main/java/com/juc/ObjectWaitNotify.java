package com.juc;

import java.util.concurrent.atomic.AtomicInteger;

public class ObjectWaitNotify {


    public static void main(String[] args) {
        AtomicInteger queue = new AtomicInteger(0);
        new Thread(new Producer(queue)).start();
        new Thread(new Consumer(queue)).start();
    }


}

class Producer implements Runnable {

    private AtomicInteger queue;
    public Producer(AtomicInteger queue) {
        this.queue = queue;
    }

    public void run() {
        while (true){
//            synchronized (queue) {
                while (queue.intValue() > 0) {

                    // 队列满了就挂起当前线程，并释放获取的queue的锁，让消费者可以拿到queue的锁，然后进行消费
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                queue.set(3);
                System.out.println("生产者已生产满队列，等待消费者进行消费");
                queue.notify();
            }
//        }

    }
}

class Consumer implements Runnable {

    private AtomicInteger queue;
    public Consumer(AtomicInteger queue) {
        this.queue = queue;
    }

    public void run() {
        while(true) {
            //不加同步的话，就可能会报错：IllegalMonitorStateException；加上之后就不会报错
//            synchronized (queue) {
                while (queue.intValue() == 0) {

                    // 队列空了就挂起当前线程，并释放获取的queue的锁，让生产者可以拿到queue的锁，然后进行生产
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                queue.set(0);
                System.out.println("消费者已消费完队列，等到生产者生产");
                queue.notify();
            }
//        }
    }
}


