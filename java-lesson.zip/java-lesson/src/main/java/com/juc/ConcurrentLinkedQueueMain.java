package com.juc;

import java.util.concurrent.ConcurrentLinkedQueue;

public class ConcurrentLinkedQueueMain {

    public static void main(String[] args) {

        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();

        queue.offer("aa"); //向队尾插入元素
        queue.add("bb"); //向队尾插入元素

        String headString = queue.poll(); //从队首取出并移除一个元素
        String headString2 = queue.peek(); //从队首获取一个元素，但只获取不移除

        int size = queue.size(); //会遍历链表，遍历过程有其他线程插入就造成结果不准确

        boolean del_success = queue.remove("aa"); //如果有重复元素，则删除第一个

        boolean isContains = queue.contains("bb"); ////会遍历链表，遍历过程有其他线程插入就造成结果不准确




    }


}
