package com.juc;

import java.util.Date;

public class Synchronized1 {

    public static void main(String[] args) {
        final Object obj = new Object();

        Thread t1 = new Thread(new Runnable() {
            public void run() {
                synchronized (obj) {
                    System.out.println(new Date() +"  t1 get obj lock");
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(new Date() +"  t1 release obj lock");
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            public void run() {
                synchronized (obj) {
                    System.out.println(new Date() +"  t2 get obj lock");
                }
            }
        });

        Thread t3 = new Thread(new Runnable() {
            public void run() {
                synchronized (obj) {
                    System.out.println(new Date() +"  t3 get obj lock");
                }
            }
        });

        t1.start();
        t2.start();
        t3.start();
    }
}
