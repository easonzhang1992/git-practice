package com.juc;

public class IncreaseMain {

//    static volatile Integer num = 0; //volatile可以保证内存可见性，所以输出顺序绝大部分可以保证有序
    static volatile int num = 0; //各个线程都有自己的副本，所以输出的顺序可能会乱序

    public static void main(String[] args) {

        Thread[] threads = new Thread[100];
        for (int i = 0; i < 100; i++) {
            threads[i] = new Thread(new Increment());
        }

        for (int i = 0; i < 100; i++) {
            threads[i].start();
        }
    }
}


class Increment implements Runnable {

    @Override
    public void run() {
        while(true) {
            System.out.println("num=" + (IncreaseMain.num++));
        }
    }
}

