package com.juc;

/**
 * JVM进程正常退出的条件是：当最后一个非守护线程结束时
 * 也就是说守护线程有没有结束不影响JVM退出，只有用户线程才会影响
 */


public class DaemonThread {

    public static void main(String[] args) {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    ;
                }
            }
        });

        thread.setDaemon(true); //设置成守护线程之后，该JVM进程就会退出；否则该JVM就不会退出，而会一直在运行
        thread.start();


        System.out.println("main thread is over");

    }

}
