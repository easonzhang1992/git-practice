package com.juc;

import java.util.Date;

public class ThreadJoin {

    public static void main(String[] args) throws Exception{

        Thread threadA = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(3000);
                    System.out.println(new Date() + "  threadA sleep over");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread threadB = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(3000);
                    System.out.println(new Date() + "  threadB sleep over");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        threadA.start();
        threadB.start();

        threadA.join();
        threadB.join();

        System.out.println(new Date() + "  all child thread over");
    }

}
