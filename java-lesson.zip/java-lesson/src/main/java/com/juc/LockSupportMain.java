package com.juc;

import java.util.concurrent.locks.LockSupport;

public class LockSupportMain {

    public static void main(String[] args) {

        LockSupport.parkUntil(3000);
        System.out.println("main thread end park");

        /*Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println(Thread.currentThread().getName() + "\t" + new Date() + "  begin park");

                while(!Thread.currentThread().isInterrupted()) {
                    LockSupport.park();
                }

                System.out.println(Thread.currentThread().getName() + "\t" + new Date() + "  end park");
            }
        });

        thread.start();

        try {
            Thread.sleep(2000);
            System.out.println(Thread.currentThread().getName() + "\t" + new Date() + "休眠结束，将中断子线程");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        thread.interrupt();

//        LockSupport.unpark(thread);

        System.out.println("main thread end park");*/
    }

}
