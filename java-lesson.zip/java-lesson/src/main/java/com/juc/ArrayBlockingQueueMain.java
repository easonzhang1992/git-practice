package com.juc;

import java.util.concurrent.ArrayBlockingQueue;

public class ArrayBlockingQueueMain {

    public static void main(String[] args) throws Exception {

        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(1);
        queue.add("aa");
        queue.offer("dd");
        queue.put("ee");



        while (true) {
//            queue.poll();
//            queue.take();
            queue.peek();
        }





    }

}
