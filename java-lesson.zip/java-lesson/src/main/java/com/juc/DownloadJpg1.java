package com.juc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class DownloadJpg1 {

    private static int num = 1;
    private static String savePath = "G:\\source files\\images\\";

    public static void main(String[] args) throws Exception {


        String path = "G:\\source files\\url22\\url1\\";
        File file = new File(path);
        File [] files = file.listFiles();
        for(File f : files) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
            String line;
            while((line = reader.readLine() ) != null) {

                if(line.endsWith("jpg")) {
                    readJpg(line);
                }

            }
            reader.close();
        }

    }

    private static void readJpg(String httpUrl) throws Exception {

        String fileName = "";

        try {

            fileName = savePath + httpUrl.substring(httpUrl.lastIndexOf("/") + 1);
            File file = new File(fileName);

            if (file.exists()) {
                return;
            }

            URL url = new URL(httpUrl);
            URLConnection conn = url.openConnection();
            InputStream input = conn.getInputStream();
            byte[] buffer = new byte[4096];
            int n;
            OutputStream output = new FileOutputStream(file);

            while ((n = input.read(buffer)) != -1) {
                output.write(buffer, 0, n);
            }

            output.close();
            input.close();

            System.out.println(num++ + " :已下载并保存 " + fileName);

        }catch (Exception e) {
            System.out.println(" 下载并保存图片 " + fileName + " 时出错，将继续下载其他图片");

        }

    }

}
