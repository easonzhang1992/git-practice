package com.juc;

import java.util.concurrent.atomic.LongAdder;

public class AtomicLongAdderMain {

    static LongAdder longAdder = new LongAdder();

    public static void main(String[] args) {

        Thread[] threads = new Thread[100];
        for (int i = 0; i < 100; i++) {
            threads[i] = new Thread(new Increment1());
        }

        for (int i = 0; i < 100; i++) {
            threads[i].start();
        }
    }
}


class Increment1 implements Runnable {

    @Override
    public void run() {
        while(true) {
            long value = AtomicLongAdderMain.longAdder.longValue();
            if(value == 1000) {
                System.exit(0);
            }
            System.out.println("num=" + value );
            AtomicLongAdderMain.longAdder.add(1);
        }
    }
}

