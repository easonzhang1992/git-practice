package com.juc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapMain {

    public static void main(String[] args) {

        final ConcurrentHashMap<String, List<String>> map = new ConcurrentHashMap<>();

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                List<String> list = new ArrayList<>();
                list.add("aa");
                map.put("1", list);
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                List<String> list = new ArrayList<>();
                list.add("bb");
//                map.put("1", list);
                List<String> oldList = map.putIfAbsent("1", list);
                if(oldList != null) {
                    //原来存在该key了，现在叠加
                    oldList.addAll(list);
                }
            }
        });

        t1.start();
        t2.start();

        for(Map.Entry<String, List<String>> entry : map.entrySet()) {
            String key = entry.getKey();
            List<String> value = entry.getValue();

            System.out.println("key=" + key);
            for(String v : value) {
                System.out.println("value=" + v);
            }

            System.out.println("======================");
        }

    }

}
