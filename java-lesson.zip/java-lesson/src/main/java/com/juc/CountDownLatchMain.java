package com.juc;

import java.util.Date;
import java.util.concurrent.CountDownLatch;

public class CountDownLatchMain {
    public static void main(String[] args) {

        final CountDownLatch countDownLatch = new CountDownLatch(2);

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(new Date() +"  t1 release countdownlatch");
                countDownLatch.countDown();
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(new Date() +"  t2 release countdownlatch");
                countDownLatch.countDown();
            }
        });

        t1.start();
        t2.start();

        try {
            System.out.println(new Date() + "  main thread is waiting");
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(new Date() + "  main thread over");


    }

}
