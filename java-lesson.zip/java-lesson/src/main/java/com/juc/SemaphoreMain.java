package com.juc;

import java.util.Date;
import java.util.concurrent.Semaphore;

public class SemaphoreMain {

    public static void main(String[] args) throws Exception {

        Semaphore semaphore = new Semaphore(1);

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println(new Date() + "  t1 arrive semaphore");
                semaphore.release();
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(new Date() + "  t2 arrive semaphore");
                semaphore.release();
            }
        });

        t1.start();
        t2.start();

        semaphore.acquire(2);

        System.out.println(new Date() + " main thread semaphore.acquire");

    }




}
