package com.juc;

public class ThreadInterrupt2 {

    public static void main(String[] args) {

        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true) {
                    ;
                }
            }
        });

        thread1.start();

        thread1.interrupt(); //设置中断标志

        System.out.println("isInterrupted:" + thread1.isInterrupted());


    }
}
