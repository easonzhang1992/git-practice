package com.juc;

import java.util.concurrent.ThreadLocalRandom;

public class ThreadLocalRandomMain {

    public static void main(String[] args) {

        ThreadLocalRandom random = ThreadLocalRandom.current();
        int randomNumber = random.nextInt(10);

    }

}
