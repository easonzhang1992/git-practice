package com.juc;

public class ThreadLocalMain {

    private static ThreadLocal<String> local = new ThreadLocal<String>();

    public static void main(String[] args) {


        local.set("aa");
        local.set("bb");


       /* Thread t1 = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    local.remove();
                    local.set("t1 thread value");
                    System.out.println("t1 thread value=" + local.get());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    local.remove();
                    local.set("t2 thread value");
                    System.out.println("t2 thread value=" + local.get());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t1.start();
        t2.start();*/

    }

}
