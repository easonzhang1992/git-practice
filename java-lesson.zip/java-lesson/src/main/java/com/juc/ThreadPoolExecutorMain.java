package com.juc;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadPoolExecutorMain {

    public static void main(String[] args) throws Exception {

        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                1, 10,
                3,TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(4),
                new MyThreadFactory(),
                new ThreadPoolExecutor.DiscardPolicy());

        executor.execute(new HelloExecuteRun());

        executor.submit(new Runnable() {
            @Override
            public void run() {
                System.out.println("hello submit");
            }
        });

        Future future =  executor.submit(new Task());
        System.out.println(future.get());

//        executor.shutdownNow();

        /**
         * shutdown和awaitTermination为接口ExecutorService定义的两个方法，一般情况配合使用来关闭线程池。
         *
         * shutdown方法：平滑的关闭ExecutorService，当此方法被调用时，
         * ExecutorService停止接收新的任务并且等待已经提交的任务（包含提交正在执行和提交未执行）执行完成。
         * 当所有提交任务执行完毕，线程池即被关闭。
         *
         * awaitTermination方法：接收人timeout和TimeUnit两个参数，用于设定超时时间及单位。
         * 当等待超过设定时间时，会监测ExecutorService是否已经关闭，若关闭则返回true，否则返回false。
         *
         * 一般情况下会和shutdown方法组合使用。
         */

        executor.shutdown(); //调用该方法后，如果某个任务执行时间很长，在该任务执行期间内线程池不会关闭的
        executor.awaitTermination(10, TimeUnit.SECONDS); //不管线程池当前有没有关闭，10秒必须关闭掉，

    }

    private static class HelloExecuteRun implements Runnable {

        @Override
        public void run() {
            System.out.println("hello execute");
        }
    }


    static class MyThreadFactory implements ThreadFactory {

        private AtomicInteger threadNum = new AtomicInteger(0);

        @Override
        public Thread newThread(Runnable r) {
            Thread thread = new Thread(r);
            thread.setName("my-thread-pool-" + threadNum.getAndIncrement());
            return thread;

        }
    }

    static class Task implements Callable<String> {

        @Override
        public String call() throws Exception {
            return "hello, callable";
        }
    }



}
