package com.juc;

public class ObjectWaitNotify2 {

    private static volatile Object resourceA = new Object();

    public static void main(String[] args) {

        Thread threadA = new Thread(new Runnable() {
            public void run() {
                synchronized (resourceA) {
                    System.out.println("threadA get resourceA lock");
                    try {
                        System.out.println("threadA begin wait");
                        resourceA.wait();
                        System.out.println("threadA end wait");
                    }catch (InterruptedException e) {
                        e.printStackTrace();

                    }
                }

            }
        });

        Thread threadB = new Thread(new Runnable() {
            public void run() {
                synchronized (resourceA) {
                    System.out.println("threadB get resourceA lock");
                    try {
                        System.out.println("threadB begin wait");
                        resourceA.wait();
                        System.out.println("threadB end wait");
                    }catch (InterruptedException e) {
                        e.printStackTrace();

                    }
                }

            }
        });

        Thread threadC = new Thread(new Runnable() {
            public void run() {
                synchronized (resourceA) {
                    try {
                        System.out.println("threadC begin notify");
                        resourceA.notifyAll();
                    }catch (Exception e) {
                        e.printStackTrace();

                    }
                }

            }
        });

        threadA.start();
        threadB.start();
        threadC.start();

        try {
            threadA.join();
            threadB.join();
            threadC.join();

        }catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("main over");

    }

}
