package com.juc;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SimpleDateFormatMain {

    public static void main(String[] args) {

        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        for(int i=0; i<10; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        sf.parse("2019-02-23 08:08:08");
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }

        Thread t = new Thread();
        t.setName("my-thread");

    }

}
