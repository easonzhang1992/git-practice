package com.juc;

import java.util.Date;

/**
 * 本例子是为了验证Thread.sleep()期间不会释放锁资源
 * 而Object.wait()和notify()、notifyAll()会释放锁资源
 */
public class ThreadSleep {

    private static volatile Object resourceA = new Object();

    public static void main(String[] args) {

        Thread threadA = new Thread(new Runnable() {
            public void run() {
                synchronized (resourceA) {
                    System.out.println(new Date() + "   threadA get resourceA lock");
                    try {
                        Thread.sleep(3000);
                        System.out.println(new Date() +"   threadA end wait");
                    }catch (InterruptedException e) {
                        e.printStackTrace();

                    }
                }

            }
        });

        Thread threadB = new Thread(new Runnable() {
            public void run() {
                synchronized (resourceA) {
                    System.out.println(new Date() + "  threadB get resourceA lock");
                    try {
                        Thread.sleep(3000);
                        System.out.println(new Date() + "   threadB end wait");
                    }catch (InterruptedException e) {
                        e.printStackTrace();

                    }
                }

            }
        });

        threadA.start();
        threadB.start();


    }
}
