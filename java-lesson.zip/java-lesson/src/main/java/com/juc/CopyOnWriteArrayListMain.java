package com.juc;

import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListMain {

    public static void main(String[] args) {

        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<String>();
        list.add("aa");
        String s1 = list.get(0);

    }

}
