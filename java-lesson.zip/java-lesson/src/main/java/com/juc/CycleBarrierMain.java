package com.juc;

import java.util.Date;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class CycleBarrierMain {

    public static void main(String[] args) {

        final CyclicBarrier cyclicBarrier = new CyclicBarrier(2, new Runnable() {
            @Override
            public void run() {
                System.out.println(new Date() +
                        "  barrier is over, now signal await threads");
            }
        });

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    System.out.println(new Date() + " t1-0 now await barrier");
                    Thread.sleep(5000);
                    cyclicBarrier.await();
                    System.out.println(new Date() + " t1-1 over barrier");

                    System.out.println(new Date() + " t1-2 now await barrier");
                    cyclicBarrier.await();
                    System.out.println(new Date() + " t1-3 over barrier");

                } catch (InterruptedException e) {
                    System.out.println(new Date() + " t1 InterruptedException ");

                } catch (BrokenBarrierException e) {
                    System.out.println(new Date() + " t1 BrokenBarrierException ");
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    System.out.println(new Date() + " t2-0 now await barrier");
                    cyclicBarrier.await(2000, TimeUnit.MILLISECONDS);
                    System.out.println(new Date() + " t2-1 over barrier");

                    System.out.println(new Date() + " t2-2 now await barrier");
                    cyclicBarrier.await();
                    System.out.println(new Date() + " t2-3 over barrier");

                }catch (TimeoutException e) {
                    System.out.println(new Date() + "  TimeoutException");

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        t1.start();
        t2.start();


    }

}
