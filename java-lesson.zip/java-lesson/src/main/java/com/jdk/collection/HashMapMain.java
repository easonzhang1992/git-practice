package com.jdk.collection;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ArrayBlockingQueue;

public class HashMapMain {

    public static void main(String[] args) {

        Map<String, String> map = new HashMap<String, String>();
        map.put("aa", "111");

        map.get("aa");
        map.containsKey("aa");
        map.remove("aa");
        map.clear();
        map.size();


        Iterator<Map.Entry<String, String>> iter = map.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<String, String> entry = iter.next();
            String key = entry.getKey();
            String value = entry.getValue();
        }


        for (Map.Entry<String, String> entry : map.entrySet()) {

            String key = entry.getKey();
            String value = entry.getValue();

        }


        for (String key : map.keySet()) {
        }

        for (String value : map.values()) {
        }


        Map<String, String> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("aa","11");
        linkedHashMap.put("bb","22");
        linkedHashMap.put("cc","33");
        linkedHashMap.put("dd","44");

        linkedHashMap.put("aa","55");

        Set<Map.Entry<String, String>> set =  linkedHashMap.entrySet();

        for (Map.Entry<String, String> entry : set) {
            System.out.println("key=" + entry.getKey());
            System.out.println("value=" + entry.getValue());
            System.out.println("=================");
        }


        Map<Integer, Integer> treeMap = new TreeMap<>();

        Set<String> hashSet = new HashSet<>();
        hashSet.add("aa");
        hashSet.add("aa");
        hashSet.add("bb");

        System.out.println("size=" + hashSet.size());

        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add("aa");
        linkedHashSet.add("bb");
        linkedHashSet.add("cc");

        TreeSet<String> treeSet = new TreeSet<>();
        treeSet.add("aa");
        treeSet.add("bb");
        treeSet.add("cc");

        Hashtable<String, String> hashtable = new Hashtable<>();
        hashtable.put("aa", "11");
        hashtable.put("bb", "22");
        hashtable.put("cc", "33");

        Queue<String> queue = new ArrayBlockingQueue<String>(2);


    }


}
