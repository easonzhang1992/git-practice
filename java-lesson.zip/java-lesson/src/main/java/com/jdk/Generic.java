package com.jdk;

import java.util.ArrayList;
import java.util.List;

public class Generic<T> {

    private T key;

    public Generic(T key) {
        this.key = key;
    }

    public T getKey() {
        return key;
    }

    public static void main(String[] args) {

        Generic<String> generic = new Generic<>("string str");
        System.out.println(generic.getKey());

        List<?>[] ls = new ArrayList<?>[10];


    }

}
