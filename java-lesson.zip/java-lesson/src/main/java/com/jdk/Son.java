package com.jdk;

public class Son extends Father {

//    String str = "I am son";

   /* @Override
    public String getStr() {
        return str;
    }*/

   public Son() {
       super("father"); //如果父类没有无参构造器，则子类必须显示地指定父类构造器
       System.out.println("son");
   }

   public Son(String str) {
       super("father");
       System.out.println("son str");
   }

    public static void main(String[] args) {

        Father father = new Son();
        System.out.println(father.getStr());


    }
}
