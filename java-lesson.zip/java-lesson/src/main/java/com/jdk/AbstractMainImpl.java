package com.jdk;


public class AbstractMainImpl extends AbstractMain {

    @Override
    public void step1() {
        System.out.println("step1");
    }

    @Override
    public void step2() {
        System.out.println("step2");
    }


    public static void main(String[] args) {

        AbstractMainImpl abstractMain = new AbstractMainImpl();
        abstractMain.step();

    }


}
