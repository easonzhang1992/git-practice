package com.jdk;

public class Father {


    private String str = "I am father";

    public Father (){}

    public Father(String str) {
        this.str = str;
    }

    public String getStr() {
        return str;
    }
}
