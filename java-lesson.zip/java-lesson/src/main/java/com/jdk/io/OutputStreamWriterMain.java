package com.jdk.io;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class OutputStreamWriterMain {

    public static void main(String[] args) throws Exception {

        File file = new File("D:\\GitHubCodes\\src\\txt\\io.txt");
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "GBK");

        outputStreamWriter.write("又是星期六啊\r\n");
        outputStreamWriter.flush();

        //TODO 关闭资源，这里不写了


    }

}
