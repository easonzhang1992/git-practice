package com.jdk.io;

import java.io.File;
import java.io.FileOutputStream;

public class FileOutputStreamMain {

    public static void main(String[] args) throws Exception {

        File file = new File("D:\\GitHubCodes\\src\\txt\\io.txt");
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);

        //只能写入byte[]，也就是字节流，没办法定义编码
        fileOutputStream.write("hello".getBytes());

        //TODO 关闭资源，这里不写了

    }



}
