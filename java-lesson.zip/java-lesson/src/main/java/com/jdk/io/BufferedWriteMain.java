package com.jdk.io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;

public class BufferedWriteMain {

    public static void main(String[] args) throws Exception {

        File file = new File("D:\\GitHubCodes\\src\\txt\\io.txt");
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "GBK");
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

        bufferedWriter.write("今天星期六\r\n");
        bufferedWriter.flush();


        //TODO 关闭流资源，这里不写了

    }



}
