package com.jdk.io;

import java.io.File;
import java.io.FileInputStream;


/**
 * inputstream只能读取字节流，每办法定义编码格式
 */
public class InputStreamMain {

    public static void main(String[] args) throws Exception{

        File file = new File("D:\\GitHubCodes\\src\\txt\\io.txt");
        FileInputStream fileInputStream = new FileInputStream(file);

        StringBuilder sb = new StringBuilder();

        int temp = 0;
        while ((temp = fileInputStream.read()) != -1) {
            sb.append(temp);
        }

        System.out.println(sb.toString());

    }

}
