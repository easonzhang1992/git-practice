package com.jdk.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class InputStreamReaderMain {

    public static void main(String[] args) throws Exception {

        File file = new File("D:\\GitHubCodes\\src\\txt\\io.txt");
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "GBK");

        StringBuilder sb = new StringBuilder();

        //带buffe的读取
        char[] buffer = new char[(int)file.length()];
        while (inputStreamReader.read(buffer) != -1) {
            sb.append(buffer);
        }

        System.out.println(sb.toString());
        System.out.println("=======================");

        //不带buffer的一个字节一个字节地读取
        int temp = 0;
        while ((temp = inputStreamReader.read()) !=-1) {
            sb.append(temp);
        }
        System.out.println(sb.toString());


    }


}
