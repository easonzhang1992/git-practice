package com.jdk;

public abstract class AbstractMain {

    public void step() {
        System.out.println("begin step");
        step1();
        step2();
    }

    public abstract void step1();
    public abstract void step2();

}
