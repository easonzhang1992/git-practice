package com.jdk;

import java.util.ArrayList;
import java.util.List;

public class FinalMain extends Father {

    public FinalMain() {
        super();
    }



    public static void main(String[] args) {

        StringBuilder s = new StringBuilder();
        s.append("aa");
        changeValue(s);
        System.out.println(s.toString());

        int i = 10____000_000;
        System.out.println(i);

        FinalMain main = new FinalMain();
        System.out.println(main.getStr());


    }

    private static StringBuilder changeValue(StringBuilder a) {
        StringBuilder s = new StringBuilder();
        s.append("aa");
        s.append("bb");
        a = s;
//        s.append("bb");
        return a;

    }

}
