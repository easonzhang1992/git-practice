package com.kafka.codec;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;

public class MyDeserializer implements Deserializer<String> {
    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        //这里做一些初始化的工作
    }

    @Override
    public String deserialize(String topic, byte[] data) {

        //这里需要把byte[]数组转换成泛型对象并返回
        return null;
    }

    @Override
    public void close() {

        //这里做一些清理工作
    }
}
