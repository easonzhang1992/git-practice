package com.algorithm;

/**
 * @author nnzhang
 *
 * 使用链表来实现栈，push时插入队尾，pop时从尾结点弹出，效率比数组要高
 *
 */
public class LiteStack {

    private LiteLinkedList list = new LiteLinkedList();

    public void push(String data) {
        list.add(data);

    }

    public String pop() {
        return list.delete(list.size() -1 );
    }

    public String peek() {
        return list.get(0);
    }

    public static void main(String[] args) {

        LiteStack stack = new LiteStack();
        stack.push("aa");
        stack.push("bb");
        stack.push("cc");

        stack.pop();
        stack.peek();
        String value = stack.pop();
        System.out.println("value = " + value);

    }

}
