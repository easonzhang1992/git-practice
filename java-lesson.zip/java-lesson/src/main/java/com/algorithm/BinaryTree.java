package com.algorithm;

public class BinaryTree {

    public class TreeNode {
        private int data;
        private TreeNode left = null;
        private TreeNode right = null;

        public TreeNode(int data) {
            this.data = data;
        }

        public int getData() {
            return data;
        }

        public void setData(int data) {
            this.data = data;
        }

        public TreeNode getLeft() {
            return left;
        }

        public void setLeft(TreeNode left) {
            this.left = left;
        }

        public TreeNode getRight() {
            return right;
        }

        public void setRight(TreeNode right) {
            this.right = right;
        }

        @Override
        public String toString() {
            return "TreeNode{" +
                    "data='" + data + '\'' +
                    ", left=" + left +
                    ", right=" + right +
                    '}';
        }
    }

    private TreeNode root = null;
    private int height = 0;

    public TreeNode buildTree(int data) {

        TreeNode newNode = new TreeNode(data);

        if(root == null) {
            root = newNode;
            return root;

        }

        TreeNode currentIndexNode = root;
        while (true){
            if(data <= currentIndexNode.data && currentIndexNode.left == null) {
                currentIndexNode.left = newNode;
                break;

            } else if(data <= currentIndexNode.data && currentIndexNode.left != null) {
                currentIndexNode = currentIndexNode.left;

            } else if(data > currentIndexNode.data && currentIndexNode.right == null) {
                currentIndexNode.right = newNode;
                break;

            } else if(data > currentIndexNode.data && currentIndexNode.right != null) {
                currentIndexNode = currentIndexNode.right;

            }
        }

        return root;

    }

    /**
     * 前序遍历：先访问节点值，再访问左节点，最后访问右节点
     */
    public void preTraverse() {
        if(root == null) {
            throw new RuntimeException("the binary tree is empty");

        }
        _preTraverse(root);

    }

    private void _preTraverse(TreeNode node) {
        if(node != null) {
            System.out.print(node.data + "\t");
            _middleTraverse(node.left);
            _middleTraverse(node.right);
        }
    }

    /**
     * 中序遍历：先访问左节点，再访问节点值，最后访问右节点
     */
    public void middleTraverse() {

        if(root == null) {
            throw new RuntimeException("the binary tree is empty");

        }
       _middleTraverse(root);
    }

    private void _middleTraverse(TreeNode node) {
        if(node != null) {
            _middleTraverse(node.left);
            System.out.print(node.data + "\t");
            _middleTraverse(node.right);
        }
    }

    /**
     * 后序遍历：先访问左节点，再后访问右节点，最后访问节点值
     */
    public void postTraverse() {
        if(root == null) {
            throw new RuntimeException("the binary tree is empty");

        }
        _postTraverse(root);

    }

    private void _postTraverse(TreeNode node) {
        if(node != null) {
            _middleTraverse(node.left);
            _middleTraverse(node.right);
            System.out.print(node.data + "\t");
        }
    }


    public static void main(String[] args) {

        BinaryTree tree = new BinaryTree();
        int[] data = new int[]{3, 2, 4, 7, 1, 5};

        for(int i=0; i<data.length; i++) {
            tree.buildTree(data[i]);
        }

        tree.preTraverse();
        System.out.println("\n" + "--------------");

        tree.middleTraverse();
        System.out.println("\n" + "--------------");

        tree.postTraverse();
        System.out.println("\n" + "--------------");



    }



}
