package com.algorithm;

/**
 * @author nnzhang
 *
 * 长度可变的列表，底层使用数组实现
 *
 */

public class LiteArrayList {

    private int[] array;
    private int length;
    private int element;



    public LiteArrayList() {
        this(8);
    }

    public LiteArrayList(int max) {
        if(max < 0) {
            throw new IllegalArgumentException();
        }
        length = max;
        element = 0;
        array = new int[max];
    }


    public void add(int value) {

        if (needGrow()) {

        }



    }

    private boolean needGrow() {
        return element >= (length - 1);
    }

    public int get(int index) {
        return 0;
    }

    public boolean remove(int index){
        return true;
    }








}
