package com.algorithm;

/**
 * @author nnzhang
 *
 * 使用链表来实现栈，push时插入队尾，pop时从头结点弹出，效率比数组要高
 *
 */

public class LiteQueue {

    private LiteLinkedList list = new LiteLinkedList();

    public void put(String data) {
        list.add(data);

    }

    public String take() {
        return list.delete(0);
    }

    public static void main(String[] args) {

        LiteQueue queue = new LiteQueue();
        queue.put("aa");
        queue.put("bb");
        queue.put("cc");

        queue.take();
        String value = queue.take();
        System.out.println("value = " + value);

    }

}
