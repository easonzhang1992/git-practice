package com.algorithm;

/**
 * @author nnzhang
 *
 * 单向链表，头节点有值，尾节点有值，尾节点.next始终等于null
 *
 */
public class LiteLinkedList {

    public class Node {

        private String data;
        private Node next; //下一个节点

        public Node(String data) {
            this.data = data;
        }

        private void next(Node nextNode) {
            this.next = nextNode;
        }

    }


    private Node head; //头节点
    private Node tail; //尾节点
    private int size; //链表的长度

    public LiteLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    public void add(String data) {

        Node currentNode = new Node(data);

        if(size == 0) {
            head = currentNode;
            tail = currentNode;
            head.next = tail;

        } else {
            tail.next = currentNode;
        }

        tail = currentNode;
        currentNode.next = null;
        size ++;
    }

    public String get(int index) {
        return getNode(index).data;

    }

    public String delete(int index) {
        Node node = getNode(index);
        if(index == 0) {
            head = node.next;
        }else {
            Node prevNode = getNode(index -1);
            prevNode.next = node.next;
        }
        size--;
        return node.data;
    }

    public Node getNode(int index) {
        if(index < 0) {
            throw new IllegalArgumentException();
        }

        if(index > (size - 1)) {
            throw new IndexOutOfBoundsException();
        }

        if(size == 0) {
            throw new RuntimeException("the list is empty");
        }

        Node currentNode = head;
        int currentIndex = 0;
        while (currentIndex++ < index) {
            currentNode = currentNode.next;
        }
        return currentNode;
    }

    public void printList() {
        if(size == 0) {
            throw new RuntimeException("the list is empty");
        }

        Node currentNode = head;
        while (currentNode.next != null) {
            System.out.println(currentNode.data);
            currentNode = currentNode.next;
        }
        System.out.println(currentNode.data);
        System.out.println("---------------");
    }

    public int size() {
        return size;
    }


    public static void main(String[] args) {
        LiteLinkedList list = new LiteLinkedList();
        list.add("aa");
        list.add("bb");
        list.add("cc");


        list.delete(0);
        list.delete(0);
        list.printList();

    }

}
