package com.logback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.logback.foo.Foo;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.StatusPrinter;

public class MyApp2 {

    public static final Logger LOGGER = LoggerFactory.getLogger(MyApp2.class);

    public static void main(String[] args) throws Exception{

        LoggerContext lc = (LoggerContext)LoggerFactory.getILoggerFactory();
//        StatusPrinter.print(lc);

        LOGGER.debug("entering application");

//        Foo foo = new Foo();
//        foo.doIt();


        while (true) {
            Thread.sleep(2*1000);
            LOGGER.error("error happen");
        }
//        LOGGER.info("exiting application");



    }

}
