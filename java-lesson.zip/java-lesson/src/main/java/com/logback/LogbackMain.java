package com.logback;

import org.apache.log4j.spi.RootLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.StatusPrinter;

public class LogbackMain {


    public static void main(String[] args) {

        Logger logger = LoggerFactory.getLogger(LogbackMain.class);
        logger.debug("hello world");

        LoggerContext loggerContext = (LoggerContext)LoggerFactory.getILoggerFactory();
//        StatusPrinter.print(loggerContext);

        Logger root = LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.debug("root logger");

        ch.qos.logback.classic.Logger loggerParent = (ch.qos.logback.classic.Logger)LoggerFactory.getLogger("com.foo");
        loggerParent.setLevel(Level.INFO);
        loggerParent.warn("warn information");
        loggerParent.debug("debug information"); //这行日志打印不出来，因为logger的级别是INFO，所以不能打印出debug级别的日志

        Logger childLogger = LoggerFactory.getLogger("com.foo.child");
        childLogger.info("child info information");

        //这行日志打印不出来，因为 childLogger 本身没有设置日志级别，所以往父类找到了com.foo有日志级别，并作为自己的日志级别，也就是INFO
        // 所以 childLogger 的级别是INFO，不能打印出debug级别的日志
        childLogger.debug("child debug information");

        Logger x = LoggerFactory.getLogger("wombat");
        Logger y = LoggerFactory.getLogger("wombat");
        System.out.println("logger is same object = " + (x == y)); //这两个是一个对象，内部单例的，并且缓存起来

        logger.debug("the entry is {}", new Object());
        logger.debug("the new value is {}, old value is {}, initial value is {}", "33", "22", "11");

        //如果设置了ROOT的日志级别是OFF，则表示关闭所有日志输出，这时所有的日志都不会被打印
        ch.qos.logback.classic.Logger rootLogger = (ch.qos.logback.classic.Logger)LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        rootLogger.setLevel(Level.OFF);
        logger.info("after root off");



        System.exit(0);

    }

}
