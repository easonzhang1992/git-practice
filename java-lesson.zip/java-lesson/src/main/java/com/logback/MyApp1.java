package com.logback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.logback.foo.Foo;

public class MyApp1 {

    public static final Logger LOGGER = LoggerFactory.getLogger(MyApp1.class);

    public static void main(String[] args) {

        LOGGER.info("entering application");

        Foo foo = new Foo();
        foo.doIt();

        LOGGER.info("exiting application");


    }

}
