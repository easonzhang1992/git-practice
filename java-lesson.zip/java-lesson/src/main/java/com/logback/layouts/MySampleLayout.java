package com.logback.layouts;

import org.apache.commons.lang.StringUtils;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.LayoutBase;

public class MySampleLayout extends LayoutBase<ILoggingEvent> {

    private String prefix = null;
    private boolean printThreadName = true;

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setPrintThreadName(boolean printThreadName) {
        this.printThreadName = printThreadName;
    }

    @Override
    public String doLayout(ILoggingEvent event) {

        //输出以下格式的内容：10489 DEBUG [main] com.marsupial.Pouch - Hello world.
        StringBuilder sb = new StringBuilder(128);
        if(StringUtils.isNotBlank(prefix)) {
            sb.append(prefix + ": ");
        }
        sb.append(event.getTimeStamp() - event.getLoggerContextVO().getBirthTime());
        sb.append(" ");
        sb.append(event.getLevel());
        if(printThreadName == true) {
            sb.append(" [");
            sb.append(event.getThreadName());
            sb.append("] ");
        }
        sb.append(event.getLoggerName());
        sb.append(" - ");
        sb.append(event.getFormattedMessage());
        sb.append(".");
        return sb.toString();
    }
}
