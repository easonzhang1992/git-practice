package com.dubbo.hystrix;

import org.apache.commons.lang.StringUtils;

import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcResult;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.exception.HystrixRuntimeException;

public class DubboCommand extends HystrixCommand<Result> {

    private Invoker<?> invoker;
    private Invocation invocation;
    private String fallbackName;

    public DubboCommand(Setter setter, Invoker<?> invoker, Invocation invocation, String fallbackName) {
        super(setter);
        this.invoker = invoker;
        this.invocation = invocation;
        this.fallbackName = fallbackName;
    }


    @Override
    protected Result run() throws Exception {

        Result result = invoker.invoke(invocation);
        //如果远程调用异常，抛出异常执行降级逻辑
        if (result.hasException()) {
            throw new HystrixRuntimeException(HystrixRuntimeException.FailureType.COMMAND_EXCEPTION, DubboCommand.class, result.getException().getMessage(), result.getException(), null);
        }

        return result;

    }

    @Override
    protected Result getFallback() {

        if (StringUtils.isBlank(fallbackName)) {
            //抛出原本的异常
            return super.getFallback();
        }

        //默认返回固定值
        Result result = new RpcResult();
        ((RpcResult) result).setValue("发生Fallback");
        return result;


        /*try {
            //基于SPI扩展加载fallback实现
            ExtensionLoader<Fallback> loader = ExtensionLoader.getExtensionLoader(Fallback.class);
            Fallback fallback = loader.getExtension(fallbackName);
            Object value = fallback.invoke();
            return new RpcResult(value);
        } catch (RuntimeException ex) {
            throw ex;
        }*/

    }



}
