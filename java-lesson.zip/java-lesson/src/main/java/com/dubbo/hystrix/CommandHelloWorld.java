package com.dubbo.hystrix;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixThreadPoolKey;

public class CommandHelloWorld extends HystrixCommand<String> {
	
	private final String name;
	
	private static final Setter setter = Setter
										.withGroupKey(HystrixCommandGroupKey.Factory.asKey("ExampleGroup"))
										.andCommandKey(HystrixCommandKey.Factory.asKey("HelloWorld"))
										.andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("HelloWorldPool"));
		
	
	
	public CommandHelloWorld(String name) {
		super(setter);
		this.name = name;
	}

	@Override
	protected String run() throws Exception {
		return "hello " + name;
	}
	
	

}
