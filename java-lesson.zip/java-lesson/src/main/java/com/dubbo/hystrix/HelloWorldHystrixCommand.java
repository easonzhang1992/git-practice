package com.dubbo.hystrix;

import java.util.Random;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.HystrixThreadPoolKey;
import com.netflix.hystrix.HystrixThreadPoolProperties;

/**
 * CircuitBreakerRequestVolumeThreshold设置为3，意味着10s内请求超过3次就触发熔断器
 * run()中无限循环使命令超时进入fallback，执行3次run后，将被熔断，进入降级，即不进入run()而直接进入fallback
 * 如果未熔断，但是threadpool被打满，仍然会降级，即不进入run()而直接进入fallback
 */

public class HelloWorldHystrixCommand extends HystrixCommand<String> {

	private String name;
	
	public HelloWorldHystrixCommand(String name) {
		super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("commandGroup"))
				.andCommandKey(HystrixCommandKey.Factory.asKey("commandKey"))
				.andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("commandPool"))
				.andThreadPoolPropertiesDefaults(
						HystrixThreadPoolProperties.Setter().withCoreSize(200)) //// 配置线程池里的线程数，设置足够多线程，以防未熔断却打满threadpool
				.andCommandPropertiesDefaults( // 配置熔断器
						HystrixCommandProperties.Setter()
						.withCircuitBreakerEnabled(true)
						.withCircuitBreakerRequestVolumeThreshold(10)
						
						//如果在一个采样时间窗口内，失败率超过该配置，则自动打开熔断开关实现降级处理，即快速失败。默认配置下采样周期为10s，失败率为50%。
						.withCircuitBreakerErrorThresholdPercentage(70)
						.withCircuitBreakerSleepWindowInMilliseconds(5000)
						.withExecutionTimeoutInMilliseconds(1000)
//						.withCircuitBreakerForceOpen(true) // 置为true时，所有请求都将被拒绝，直接到fallback
//						.withCircuitBreakerForceClosed(true) // 置为true时，将忽略错误
//						.withExecutionIsolationStrategy(ExecutionIsolationStrategy.SEMAPHORE)  // 使用信号量隔离，也可以选择线程隔离
						
						/**
						 * 执行超时时间，默认为1000毫秒，如果命令是线程隔离，且配置了executionIsolationThreadInterruptOnTimeout=true，
						 * 则执行线程将执行中断处理。如果命令是信号量隔离，则进行终止操作，
						 * 因为信号量隔离与主线程是在一个线程中执行，其不会中断线程处理，所以要根据实际情况来决定是否采用信号量隔离，尤其涉及网络访问的情况
						 */
//						.withExecutionTimeoutInMilliseconds(5000)
						
				)
				
				
				
		);
		this.name = name;
	}

	@Override
	protected String run() throws Exception {
		
		//除零异常
//		int j = 1/0;
		
		
		//抛出runtimeException及各种自己包装的继承于RuntimeException的异常
//		throw new RuntimeException("exception...");
		
		// 超时异常，默认是2秒钟超时
//		Thread.sleep(100*1000);
//		
//		return "hello " + name;
		
		/*System.out.println("running run():" + name);
		int j = 0;
		while(true) {
			j++;
		}*/
		
		
		Random random = new Random();
    	if(1 == random.nextInt(2)) {	// 直接返回
    		return name;
    	} else {	// 无限循环模拟超时
    		throw new Exception("make exception");
    	}
		
		
	}
	
	/**
	 * 以下四种情况将触发getFallback调用：
	 * 1）run()方法抛出非HystrixBadRequestException异常
	 * 2）run()方法调用超时
	 * 3）熔断器开启拦截调用
	 * 4）线程池/队列/信号量是否跑满
	 * 
	 * 如果没有重写该方法，则发生异常时不会有任何响应输出，好像被Hystrix吞掉了一样
	 */
	@Override
	protected String getFallback() {
		return "  fallback " +  name;
	}
	
	

}
