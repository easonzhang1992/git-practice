package com.dubbo.service;

public class ProviderServiceImpl implements ProviderService {


    public String sayHello(String name) {
        return "hello ~~~~~~ " + name + ",你好，你好啊";
    }
}
