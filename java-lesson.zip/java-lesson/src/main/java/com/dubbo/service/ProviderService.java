package com.dubbo.service;

public interface ProviderService {
    String sayHello(String name);
}
