package com.hikariCP;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.pool.HikariProxyConnection;
import com.zaxxer.hikari.util.IsolationLevel;

public class HikariCPMain {

    public static void main(String[] args) throws Exception {

        HikariConfig config = new HikariConfig();

        String url = "jdbc:mysql://localhost:3306/mybatis?characterEncoding=utf8&useSSL=false";
        String username = "root";
        String password = "1234";

        config.setJdbcUrl(url);
        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(100);

        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.setConnectionTimeout(20 * 1000);

        //这句话可以让连接泄漏检测开启，只要getConnection超过3秒没有还回去，就会打印日志，如：
        //[HikariPool-1 housekeeper] WARN  c.z.h.p.ProxyLeakTask -
        // Connection leak detection triggered for com.mysql.jdbc.JDBC4Connection@63070bab on thread main,stack trace follows
        config.setLeakDetectionThreshold(TimeUnit.SECONDS.toMillis(3));

        HikariDataSource dataSource = new HikariDataSource(config);
        HikariProxyConnection connection = (HikariProxyConnection)dataSource.getConnection();
        System.out.println(new Date() + "connection=" + connection);

        Statement stmt = connection.createStatement();
        String sql = "select user_name from sys_user where id=2";

        connection.setAutoCommit(false);
        connection.setTransactionIsolation(IsolationLevel.TRANSACTION_READ_COMMITTED.getLevelId());
        try {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String user_name = rs.getString("user_name");
                System.out.println("user_name=" + user_name);
            }

            connection.commit();

        }catch (Exception e) {
            connection.rollback();

        }finally {
            connection.close();
        }



       /* Thread.sleep(5000);
        System.out.println("连接要关闭了...");
        connection.close();
        System.out.println("连接已关闭了...");*/

    }


}
