package com.spring.lesson1;

import org.springframework.stereotype.Service;

@Service
public class Person {
	private String name;
	private User user;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", user=" + user + "]";
	}
	
}
