package com.spring.lesson1;

public class Dog {
	private String name;
	private Color color;
	
	public Dog() {}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Dog [name=" + name + ", color=" + color + "]";
	}



	class Color{
		private String colorName;
		
		public Color() {}

		public String getColorName() {
			return colorName;
		}

		public void setColorName(String colorName) {
			this.colorName = colorName;
		}

		@Override
		public String toString() {
			return "Color [colorName=" + colorName + "]";
		}
	}

}
