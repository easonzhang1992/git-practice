package com.spring.lesson1;

public class UserFactory {
	private static User user = new User();
	private UserFactory() {}
	
	public static User createUser() {
		return user;
	}
	
	public User createUser2() {
		return user;
	}
}
