package com.spring.lesson1;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class UserService implements ApplicationContextAware {
	private ApplicationContext applicationContext;

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext  = applicationContext;
	}
	
	public User getUser() {
		return this.applicationContext.getBean("user", User.class);
	}
	
}
