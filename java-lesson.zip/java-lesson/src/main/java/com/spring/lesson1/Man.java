package com.spring.lesson1;

public class Man {
	private User user;
	private String name;
	private String sex;
	private int age;
	
	public Man(User user, String name, String sex, int age) {
		this.user = user;
		this.name = name;
		this.sex = sex;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Man [user=" + user + ", name=" + name + ", sex=" + sex + ", age=" + age + "]";
	}

}
