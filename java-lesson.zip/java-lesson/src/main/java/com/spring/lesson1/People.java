package com.spring.lesson1;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class People {
	private String name;
	private User user;
	private Dog dog;
	
	@Autowired
	private Cat cat;
	
	@Autowired
	public People(User user) {
		this.user = user;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public User getUser() {
		return user;
	}
	@Autowired //自动注入
	@Required //该依赖是必须的，不可为空
	@Resource //查找bean id为user的bean进行注入
	
	@Qualifier(value="user4") //查找bean id是user4的bean进行注入
	public void setUser(User user) {
		this.user = user;
	}
	
	@PostConstruct //初始化回调方法，相当于xml中的init-method属性
	public void init() {
		System.out.println("init...");
	}
	
	@PreDestroy //销毁回调方法,相当于xml中的destroy-method属性
	public void destroy() {
		System.out.println("destroy...");
	}
	
	public Dog getDog() {
		return dog;
	}

	@Autowired
	public void setDog(Dog dog) {
		this.dog = dog;
	}

	public Cat getCat() {
		return cat;
	}

	public void setCat(Cat cat) {
		this.cat = cat;
	}

	@Override
	public String toString() {
		return "People [name=" + name + ", user=" + user + ", dog=" + dog + ", cat=" + cat + "]";
	}

}
