package com.spring.lesson1;

public class User {
	private int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [age=" + age + "]";
	}
	
	public void init() {
		System.out.println("user init...");
	}
	
	public void destroy() {
		System.out.println("user destroy...");
	}
}
