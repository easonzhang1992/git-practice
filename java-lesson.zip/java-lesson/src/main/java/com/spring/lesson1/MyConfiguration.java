package com.spring.lesson1;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;

@Configuration
@Import(User.class) //一般来说，User类也要被@Configuration注释，该注解相当于xml中<import />标签
public class MyConfiguration {
	
	
	@Bean
	public User getUser() {
		return new User();
	}
	
	@Bean
	@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	@Description("这是一个注释，用于解释该bean的作用等")
	public Person getPerson() {
		return new Person();
	}
}
