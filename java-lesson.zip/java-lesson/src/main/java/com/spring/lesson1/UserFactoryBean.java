package com.spring.lesson1;

import org.springframework.beans.factory.FactoryBean;

public class UserFactoryBean implements FactoryBean<User>{
	private static User user = new User();
	public User getObject() throws Exception {
		user.setAge(38);
		return user;
	}

	public Class<?> getObjectType() {
		return User.class;
	}

	public boolean isSingleton() {
		return true;
	}
	
}
