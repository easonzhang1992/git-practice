package com.spring;

import java.lang.management.ManagementFactory;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AopMain {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(AopConfig.class);

        String pidName = ManagementFactory.getRuntimeMXBean().getName();

        //不要自己创建对象, 要从spring容器中获取对象
        MathCalculator mathCalculator = applicationContext.getBean(MathCalculator.class);
//        IMathCalculator mathCalculator = applicationContext.getBean(IMathCalculator.class);

        int result = mathCalculator.div(1, 1);

        System.out.println("计算结果=" + result);

        String name = mathCalculator.getClass().getName();
        System.out.println("name=" + name);

    }

}
