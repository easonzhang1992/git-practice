package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMain {

    public static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml", "spring.xml");

        Person person = (Person) context.getBean("person");

        System.out.println(person);

    }

}
