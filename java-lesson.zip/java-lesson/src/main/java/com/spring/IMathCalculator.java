package com.spring;

public interface IMathCalculator {

    int div(int i, int j);
}
