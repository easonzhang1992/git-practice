package com.spring.lesson2.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ConcurrentOperationExecutor implements Ordered {

	private static final int DEFAULT_MAX_RETRIES = 2;
	private int maxRetries = DEFAULT_MAX_RETRIES;
	private int order = 1;

	@Override
	public int getOrder() {
		return this.order;
	}
	
	public void setOrder(int order) {
		this.order = order;
	}

	public void setMaxRetries(int maxRetries) {
		this.maxRetries = maxRetries;
	}

	@Around("com.spring.lesson2.aop.SystemArchitecture.businessService()")
	public Object doConcurrentOperation(ProceedingJoinPoint pjp) throws Throwable {
		int numAttempt = 0;
		PessimisticLockingFailureException lockFailureException;
		do {
			numAttempt++;
			try {
				return pjp.proceed();
			}catch(PessimisticLockingFailureException ex) {
				lockFailureException = ex;
			}
		}while(numAttempt <= this.maxRetries);
		throw new PessimisticLockingFailureException("重试失败");
		
	}
}
