package com.spring.lesson2.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class FooAspect {
	
	
	@Pointcut("execution(*transfer(..))")
	private void anyOldTransfer() {
		//用于pointcut的方法的返回值必须是void
	}
	
	
	
}
