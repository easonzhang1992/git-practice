package com.spring.lesson2.aop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class PersonMan {
	
	@Autowired ApplicationContext context;

	public String sayHello(String name) {
		System.out.println("hello, person, name = " + name);
		testUseAop();
		return name;
	}
	
	public void testUseAop() {
		System.out.println("测试有没有被增强：");
	}

	public void throwException() {
		System.out.println("准备抛出异常了...");
		throw new RuntimeException("正式抛出异常...");
	}
}
