package com.spring.lesson2.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class SystemArchitecture {

	/**
	 * 如果方法在com.xyz.someapp.web包中的类型中定义或者在其下包含任何子包，则Web层中将有一个连接点。
	 */
	@Pointcut("with(com.xyz.someapp.web..*)")
	public void inWebLayer() {
		
	}
	
	/**
	 * 如果方法在com.xyz.someapp.service包中的类型中定义或者在其下包含任何子包，则service层中将有一个连接点。
	 */
	@Pointcut("within(com.xyz.someapp.service..*)")
	public void inServiceLayer() {
		
	}
	
	/**
	 * 如果方法在com.xyz.someapp.dao包中的类型中定义或者在其下包含任何子包，则dao层中将有一个连接点。
	 */
	@Pointcut("within(com.xyz.someapp.dao..*)")
	public void inDataAccessLayer() {
		
	}
	
	/**
	 businessService是执行在service 接口上定义的任何方法。该定义假定接口放置在“service”包中，并且实现类型位于子包中。 
	如果按功能区域对服务接口进行分组（例如，在包com.xyz.someapp.abc.service和com.xyz.someapp.def.service中），
	则切入点表达式“execution（* com.xyz.someapp..service.*.*（..））“ 可以被代替
	 */
	@Pointcut("execution(* com.xyz.someapp..service.*.*(..))")
	public void businessService() {
		
	}
	
	@Pointcut("execution(* com.xyz.someapp..dao.*.*(..))")
	public void dataAccessOperation() {
		
	}
	
	
}
