package com.spring.lesson2.aop;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.SourceLocation;
import org.springframework.stereotype.Component;

/**
	
	（）匹配不带参数的方法，而（..）匹配任意数量的参数（零个或多个）。
	模式（*）匹配任何类型的一个参数的方法，
	（*，String）匹配一个方法接受两个参数，第一个可以是任何类型，第二个必须是String。

	常见切入点表达式的一些示例如下所示。

	执行任何公共方法：
	execution(public * *(..))
	
	执行名称以“set”开头的任何方法：
	execution(* set*(..))
	
	执行由AccountService接口定义的任何方法：
	execution(* com.xyz.service.AccountService.*(..))
	
	执行service包中定义的任何方法：
	execution(* com.xyz.service.*.*(..))
	
	执行service包或子包中定义的任何方法：
	execution(* com.xyz.service..*.*(..))
	
	service包中的任何连接点（仅在Spring AOP中执行的方法）：
	within(com.xyz.service.*)
	
	 service包或子包中的任何连接点（仅在Spring AOP中执行的方法）：
	within(com.xyz.service..*)

	
 */

@SuppressWarnings("all")
@Aspect
@Component
public class PersonAspect {
	
	@Pointcut("execution(* PersonMan.sayHello(..))")
	private void personManPointCut() {}
	
	@Before("personManPointCut()")
	public void businessService() {
		System.out.println("this is a before aspect...");
	}
	
	@AfterReturning("execution(* PersonMan.sayHello(..))")
	public void businessService2() {
		System.out.println("this is a after-return aspect...");
	}
	
	@After("execution(* PersonMan.sayHello(..))")
	public void businessService3() {
		System.out.println("this is a after-finally aspect...");
	}
	
	@After("execution(* PersonMan.testUseAop(..))")
	public void testUseAop() {
		System.out.println("被增强了...");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	
	@Around("execution(* PersonMan.sayHello(..))")
	public String businessService4(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("this is a around-before aspect...");
		System.out.println("-------------------------");
		Object[] args = joinPoint.getArgs(); // [nnzhang]
		String kind = joinPoint.getKind(); // method-execution
		Signature s = joinPoint.getSignature(); // String com.lesson2.aop.test.PersonMan.sayHello(String)
		SourceLocation st = joinPoint.getSourceLocation(); // execution(String com.lesson2.aop.test.PersonMan.sayHello(String))
		Object thiss = joinPoint.getThis(); // com.lesson2.aop.test.PersonMan@58ebfd03
		Object targets = joinPoint.getTarget(); // com.lesson2.aop.test.PersonMan@58ebfd03
		
		String retVal = (String)joinPoint.proceed(args); // nnzhang
		System.out.println("-------------------------");
		
		System.out.println("this is a around-after aspect...");
		
		return retVal;
		
	}
	
	@AfterThrowing(pointcut = "execution(* PersonMan.throwException(..))", throwing = "ex")
	public void businessService5(RuntimeException ex) throws Throwable {
		System.out.println("检测到异常 runtimeException .....");
	}
	
}
