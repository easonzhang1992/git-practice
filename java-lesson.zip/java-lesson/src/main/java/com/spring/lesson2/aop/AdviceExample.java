package com.spring.lesson2.aop;

import java.sql.SQLException;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.expression.spel.support.DataBindingPropertyAccessor;

@Aspect
public class AdviceExample {
	
	/**
	 * 使用before通知，并声明方法
	 */
	@Before("com.lesson2.aop.SystemArchitecture.dataAccessOperation()")
	public void doAccessCheck() {
		
	}
	
	/**
	 * 使用切入点表达式重写上面的方法,查找标注为"execution(* com.xyz.someapp..dao.*.*(..))"的pointcut方法，也就是dataAccessOperation()方法
	 */
	@Before("execution(* com.xyz.someapp..dao.*.*(..))")
	public void doAccessCheck2() {
		
	}
	
	/**
	 * after-return通知
	 */
	@AfterReturning("com.lesson2.aop.SystemArchitecture.dataAccessOperation()")
	public void doAccessCheck3() {
		
	}
	
	/**
	 * after-throw通知
	 */
	@AfterThrowing("com.lesson2.aop.SystemArchitecture.dataAccessOperation()")
	public void doRecoveryActions() {
		
	}
	
	@AfterThrowing(pointcut="com.lesson2.aop.SystemArchitecture.dataAccessOperation()", throwing="ex")
	public void doRecoveryActions2(SQLException ex) {
		
	}
	
	/**
	 * after-finally通知
	 */
	@After("com.lesson2.aop.SystemArchitecture.dataAccessOperation()")
	@Order(3)
	public void doReleaseResource() {
		
	}
	
	/**
	 * around通知
	 */
	@Around("com.lesson2.aop.SystemArchitecture.businessService()")
	public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
		Object retVal = pjp.proceed();
		return retVal;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
