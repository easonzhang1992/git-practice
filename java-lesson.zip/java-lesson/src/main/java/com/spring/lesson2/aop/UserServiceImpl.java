package com.spring.lesson2.aop;

import org.springframework.transaction.annotation.Transactional;

public class UserServiceImpl {
	
	@Transactional
	public void add1(User user) {
		add2(user);
	}
	
	@Transactional
	public void add2(User user) {
		// insert user to db
	}
	
}
