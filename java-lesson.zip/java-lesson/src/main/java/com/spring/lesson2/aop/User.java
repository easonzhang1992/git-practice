package com.spring.lesson2.aop;

public class User {

}
