package com.spring;

public class MathCalculator implements IMathCalculator {

    @Override
    public int div(int i,int j){
        System.out.println("MathCalculator...div...");
        return i/j;
    }

}
