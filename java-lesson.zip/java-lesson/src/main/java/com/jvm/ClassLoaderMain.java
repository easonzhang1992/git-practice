package com.jvm;

public class ClassLoaderMain {

    public static void main(String[] args)  {

        /*ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        System.out.println("classloader=" + classLoader);

        ClassLoader parent = classLoader.getParent();
        System.out.println("parent classloader=" + parent);
        System.out.println("parent parent classloader=" + parent.getParent());*/


        String path = "E:\\java_study\\Spring\\code\\lite-spring\\src\\main\\java\\org\\litespring\\beans";

        MyClassLoader myClassLoader = new MyClassLoader();
        myClassLoader.setBasePath("E:\\java_study\\magpie\\juc\\juc-lesson\\target\\classes");

        try {
            Class<?> clz = myClassLoader.loadClass("DownloadJpg0");

            Object object = clz.newInstance();

            System.out.println("object=" + object);

            System.out.println("classloader=" + object.getClass().getClassLoader());
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

}
