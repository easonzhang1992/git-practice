package com.jvm;

import java.util.ArrayList;
import java.util.List;

public class JstackDemo1 {

    static List<Object> list = new ArrayList<>();

    public static void main(String[] args) {



        while (true) {
            Object object = new Object();
            list.add(object);
        }
    }

}

