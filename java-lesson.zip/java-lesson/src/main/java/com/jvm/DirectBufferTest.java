package com.jvm;

import java.nio.ByteBuffer;

public class DirectBufferTest {


    public static void main(String[] args) {

        while (true) {
            ByteBuffer.allocateDirect(1 * 1024 * 1024);
        }


    }

}
