package com.jvm;

import java.lang.ref.SoftReference;

public class ReferenceTest {

    public static void main(String[] args) {

        SoftReference<String> softReference = new SoftReference<String>("a");

        String value = softReference.get();

        System.out.println("value = " + value);



    }

}
